import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize Google Gemini API Client
let ai: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
  console.log("Google Gemini API client initialized successfully.");
} else {
  console.warn("WARNING: GEMINI_API_KEY is not set or is using the default placeholder value. AI features will run in simulation mode.");
}

// Simple JSON Database setup
const DB_FILE = path.join(process.cwd(), "server-db.json");

interface Preferences {
  preferredCity: string;
  tempUnit: 'C' | 'F';
  wakeupTime: string;
  workSchedule: string;
  commuteTime: string;
  exerciseHabits: string;
  favoriteActivities: string[];
  travelMethods: string[];
  dislikesHot: boolean;
  dislikesRain: boolean;
  walkPreference: 'morning' | 'evening' | 'flexible';
}

interface HistoricalLog {
  id: string;
  timestamp: string;
  city: string;
  temp: number;
  humidity: number;
  rainChance: number;
  windSpeed: number;
  aqi: number;
}

interface SavedLocation {
  city: string;
  lat: number;
  lon: number;
}

interface DBStructure {
  preferences: Preferences;
  history: HistoricalLog[];
  savedLocations: SavedLocation[];
}

const DEFAULT_DB: DBStructure = {
  preferences: {
    preferredCity: "San Francisco",
    tempUnit: "C",
    wakeupTime: "07:00",
    workSchedule: "09:00 - 17:00",
    commuteTime: "30 mins",
    exerciseHabits: "Evening running",
    favoriteActivities: ["Cycling", "Hiking", "Walking"],
    travelMethods: ["Public Transit", "Driving"],
    dislikesHot: true,
    dislikesRain: true,
    walkPreference: "evening"
  },
  history: [
    {
      id: "hist-1",
      timestamp: "2026-07-01T08:00:00Z",
      city: "San Francisco",
      temp: 16,
      humidity: 82,
      rainChance: 10,
      windSpeed: 12,
      aqi: 22
    },
    {
      id: "hist-2",
      timestamp: "2026-07-02T08:00:00Z",
      city: "San Francisco",
      temp: 17,
      humidity: 78,
      rainChance: 25,
      windSpeed: 14,
      aqi: 28
    },
    {
      id: "hist-3",
      timestamp: "2026-07-03T08:00:00Z",
      city: "San Francisco",
      temp: 15,
      humidity: 85,
      rainChance: 60,
      windSpeed: 18,
      aqi: 18
    },
    {
      id: "hist-4",
      timestamp: "2026-07-04T08:00:00Z",
      city: "San Francisco",
      temp: 18,
      humidity: 70,
      rainChance: 5,
      windSpeed: 10,
      aqi: 31
    },
    {
      id: "hist-5",
      timestamp: "2026-07-05T08:00:00Z",
      city: "San Francisco",
      temp: 20,
      humidity: 65,
      rainChance: 0,
      windSpeed: 9,
      aqi: 42
    },
    {
      id: "hist-6",
      timestamp: "2026-07-06T08:00:00Z",
      city: "San Francisco",
      temp: 19,
      humidity: 72,
      rainChance: 15,
      windSpeed: 11,
      aqi: 35
    },
    {
      id: "hist-7",
      timestamp: "2026-07-07T08:00:00Z",
      city: "San Francisco",
      temp: 21,
      humidity: 68,
      rainChance: 0,
      windSpeed: 13,
      aqi: 40
    }
  ],
  savedLocations: [
    { city: "San Francisco", lat: 37.7749, lon: -122.4194 },
    { city: "New York", lat: 40.7128, lon: -74.0060 },
    { city: "Tokyo", lat: 35.6762, lon: 139.6503 }
  ]
};

// Helper to read database
function readDB(): DBStructure {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(data);
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2), "utf-8");
    return DEFAULT_DB;
  } catch (err) {
    console.error("Error reading database file:", err);
    return DEFAULT_DB;
  }
}

// Helper to write database
function writeDB(data: DBStructure) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing database file:", err);
  }
}

app.use(express.json());

// --- Core Helper: Weather WMO Code Mappings ---
function getWeatherDescription(code: number): string {
  const map: Record<number, string> = {
    0: 'Clear sky',
    1: 'Mainly clear',
    2: 'Partly cloudy',
    3: 'Overcast',
    45: 'Foggy',
    48: 'Depositing rime fog',
    51: 'Light drizzle',
    53: 'Moderate drizzle',
    55: 'Dense drizzle',
    56: 'Light freezing drizzle',
    57: 'Dense freezing drizzle',
    61: 'Slight rain',
    63: 'Moderate rain',
    65: 'Heavy rain',
    66: 'Light freezing rain',
    67: 'Heavy freezing rain',
    71: 'Slight snow fall',
    73: 'Moderate snow fall',
    75: 'Heavy snow fall',
    77: 'Snow grains',
    80: 'Slight rain showers',
    81: 'Moderate rain showers',
    82: 'Violent rain showers',
    85: 'Slight snow showers',
    86: 'Heavy snow showers',
    95: 'Thunderstorm',
    96: 'Thunderstorm with slight hail',
    99: 'Thunderstorm with heavy hail'
  };
  return map[code] || 'Unknown weather';
}

// Map AQI index
function getAQILabel(aqi: number): string {
  if (aqi <= 50) return "Good";
  if (aqi <= 100) return "Moderate";
  if (aqi <= 150) return "Unhealthy for Sensitive Groups";
  if (aqi <= 200) return "Unhealthy";
  return "Very Unhealthy";
}

// --- API Endpoints ---

// 1. Geocoding API: City Search
app.get("/api/geocode", async (req: Request, res: Response) => {
  const q = req.query.q as string;
  if (!q) {
    res.status(400).json({ error: "Query parameter 'q' is required" });
    return;
  }

  try {
    const response = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=5&language=en&format=json`);
    const data = await response.json();
    
    if (data.results && data.results.length > 0) {
      const formatted = data.results.map((r: any) => ({
        city: `${r.name}${r.admin1 ? ', ' + r.admin1 : ''}, ${r.country}`,
        name: r.name,
        lat: r.latitude,
        lon: r.longitude,
        country: r.country,
        admin1: r.admin1
      }));
      res.json(formatted);
    } else {
      res.json([]);
    }
  } catch (error: any) {
    console.error("Geocoding error:", error);
    res.status(500).json({ error: "Failed to search for location" });
  }
});

// --- OpenWeatherMap Integrations and Fallbacks ---

function openWeatherIdToWMO(id: number): number {
  if (id >= 200 && id < 300) return 95; // Thunderstorm
  if (id >= 300 && id < 400) return 51; // Drizzle
  if (id >= 500 && id < 600) {
    if (id === 511) return 66; // Freezing rain
    if ([500, 501].includes(id)) return 61; // Slight rain
    if ([502, 503, 504].includes(id)) return 65; // Heavy rain
    return 80; // Rain showers
  }
  if (id >= 600 && id < 700) return 71; // Snow
  if (id >= 700 && id < 800) return 45; // Foggy
  if (id === 800) return 0; // Clear
  if (id === 801) return 1; // Mainly clear
  if (id === 802) return 2; // Partly cloudy
  if (id === 803 || id === 804) return 3; // Overcast
  return 0;
}

function estimateUVIndex(temp: number, weatherId: number): number {
  if (weatherId >= 800 && weatherId <= 801) { // Clear/mainly clear
    return temp > 30 ? 9 : temp > 20 ? 7 : 5;
  }
  if (weatherId >= 802 && weatherId <= 804) { // Clouds
    return temp > 20 ? 4 : 3;
  }
  return 1; // Rain, snow, storm, fog
}

async function fetchOpenMeteoFallback(lat: number, lon: number, cityName: string) {
  const forecastUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,uv_index,visibility&hourly=temperature_2m,precipitation_probability,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max&timezone=auto`;
  const forecastRes = await fetch(forecastUrl);
  const forecastData = await forecastRes.json();

  const aqUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=us_aqi`;
  const aqRes = await fetch(aqUrl);
  let aqi = 35;
  try {
    const aqData = await aqRes.json();
    if (aqData?.current?.us_aqi) {
      aqi = aqData.current.us_aqi;
    }
  } catch (_) {}

  const cur = forecastData.current;
  const daily = forecastData.daily;
  const hourly = forecastData.hourly;

  const currentHourIndex = new Date().getHours();
  const curRainChance = hourly.precipitation_probability[currentHourIndex] || 0;

  const current = {
    temp: cur.temperature_2m,
    feelsLike: cur.apparent_temperature,
    high: daily.temperature_2m_max[0],
    low: daily.temperature_2m_min[0],
    weatherCode: cur.weather_code,
    description: getWeatherDescription(cur.weather_code),
    humidity: cur.relative_humidity_2m,
    windSpeed: cur.wind_speed_10m,
    windDirection: cur.wind_direction_10m,
    pressure: cur.pressure_msl,
    uvIndex: cur.uv_index,
    airQuality: aqi,
    airQualityLabel: getAQILabel(aqi),
    sunrise: daily.sunrise[0]?.split("T")[1] || "06:00",
    sunset: daily.sunset[0]?.split("T")[1] || "20:00",
    rainChance: curRainChance,
    visibility: cur.visibility / 1000,
  };

  const hourlyForecasts = [];
  const nowHour = new Date().getHours();
  for (let i = nowHour; i < nowHour + 24; i++) {
    const idx = i % 168;
    const rawTime = hourly.time[idx];
    const timeStr = rawTime ? new Date(rawTime).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }) : `${i % 24}:00`;
    hourlyForecasts.push({
      time: timeStr,
      temp: hourly.temperature_2m[idx],
      weatherCode: hourly.weather_code[idx],
      description: getWeatherDescription(hourly.weather_code[idx]),
      rainChance: hourly.precipitation_probability[idx] || 0
    });
  }

  const dailyForecasts = [];
  for (let i = 0; i < 7; i++) {
    const rawDate = daily.time[i];
    const dateStr = rawDate ? new Date(rawDate).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }) : `Day ${i + 1}`;
    dailyForecasts.push({
      date: dateStr,
      tempMax: daily.temperature_2m_max[i],
      tempMin: daily.temperature_2m_min[i],
      weatherCode: daily.weather_code[i],
      description: getWeatherDescription(daily.weather_code[i]),
      rainChance: daily.precipitation_probability_max[i] || 0,
      uvIndex: daily.uv_index_max[i] || 0
    });
  }

  const alerts = [];
  if (current.uvIndex >= 8) {
    alerts.push({
      title: "Extreme UV Warning",
      description: "The UV index is extremely high today. Seek shade, wear protective clothing, and apply SPF 30+ sunscreen every 2 hours.",
      severity: "severe",
      time: "Today"
    });
  }
  if (current.windSpeed >= 30) {
    alerts.push({
      title: "High Wind Alert",
      description: "Strong winds are active. Secure loose outdoor objects and exercise caution while driving high-profile vehicles.",
      severity: "moderate",
      time: "Active"
    });
  }
  if (current.rainChance >= 80 && current.description.toLowerCase().includes("rain")) {
    alerts.push({
      title: "Heavy Rainfall Expected",
      description: "Heavy rain is highly probable. Driving visibility may be limited and streets could accumulate water quickly.",
      severity: "moderate",
      time: "Upcoming"
    });
  }
  if (aqi > 100) {
    alerts.push({
      title: "Poor Air Quality Advisory",
      description: "Air pollution levels are unhealthy. Sensitive individuals should limit prolonged outdoor exertion.",
      severity: "moderate",
      time: "Today"
    });
  }
  if (current.temp > 35) {
    alerts.push({
      title: "Excessive Heat Warning",
      description: "Dangerously hot conditions are present. Drink plenty of fluids, stay in air-conditioned spaces, and avoid outdoor exercise.",
      severity: "severe",
      time: "Active"
    });
  }

  return {
    city: cityName,
    lat,
    lon,
    current,
    hourly: hourlyForecasts,
    daily: dailyForecasts,
    alerts,
    dataSource: "Open-Meteo"
  };
}

async function fetchWeatherPipeline(lat: number, lon: number, cityName: string) {
  const apiKey = process.env.OPENWEATHER_API_KEY || "b1b15e88fa797225412429c1c50c122a1";
  
  try {
    // 1. Fetch Current Weather
    const cwUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    const cwRes = await fetch(cwUrl);
    if (!cwRes.ok) {
      throw new Error(`OpenWeatherMap Current API error: ${cwRes.statusText}`);
    }
    const cw = await cwRes.json();

    // 2. Fetch Air Pollution
    let aqi = 35; // Default moderate
    try {
      const apUrl = `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${apiKey}`;
      const apRes = await fetch(apUrl);
      if (apRes.ok) {
        const ap = await apRes.json();
        const rawAqi = ap?.list?.[0]?.main?.aqi || 2; // 1-5 scale, default fair (2)
        const aqiMap: Record<number, number> = { 1: 25, 2: 65, 3: 115, 4: 165, 5: 225 };
        aqi = aqiMap[rawAqi] || 65;
      }
    } catch (_) {
      // Keep fallback
    }

    // 3. Fetch Forecast
    const fcUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    const fcRes = await fetch(fcUrl);
    if (!fcRes.ok) {
      throw new Error(`OpenWeatherMap Forecast API error: ${fcRes.statusText}`);
    }
    const fc = await fcRes.json();

    // Mapping fields
    const curWeatherId = cw.weather?.[0]?.id || 800;
    const curWmoCode = openWeatherIdToWMO(curWeatherId);
    const curDescription = cw.weather?.[0]?.description || "Clear";

    const formattedSunrise = cw.sys?.sunrise 
      ? new Date(cw.sys.sunrise * 1000).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
      : "06:00";
    const formattedSunset = cw.sys?.sunset 
      ? new Date(cw.sys.sunset * 1000).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
      : "20:00";

    const curRainChance = Math.round((fc?.list?.[0]?.pop || 0) * 100);
    const uvIndex = estimateUVIndex(cw.main.temp, curWeatherId);

    const current = {
      temp: cw.main.temp,
      feelsLike: cw.main.feels_like,
      high: cw.main.temp_max,
      low: cw.main.temp_min,
      weatherCode: curWmoCode,
      description: curDescription.charAt(0).toUpperCase() + curDescription.slice(1),
      humidity: cw.main.humidity,
      windSpeed: cw.wind?.speed ? Math.round(cw.wind.speed * 3.6 * 10) / 10 : 12.5, // Convert m/s to km/h
      windDirection: cw.wind?.deg || 180,
      pressure: cw.main.pressure,
      uvIndex,
      airQuality: aqi,
      airQualityLabel: getAQILabel(aqi),
      sunrise: formattedSunrise,
      sunset: formattedSunset,
      rainChance: curRainChance,
      visibility: cw.visibility ? cw.visibility / 1000 : 10, // convert meters to km
    };

    // Hourly Forecast (Next 24 hours) - using OpenWeather 3-hour chunks (8 chunks = 24h)
    const hourlyForecasts = [];
    const listCount = Math.min(fc.list?.length || 0, 12); // take up to 36 hours of data
    for (let i = 0; i < listCount; i++) {
      const item = fc.list[i];
      const date = new Date(item.dt * 1000);
      const timeStr = date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
      const wId = item.weather?.[0]?.id || 800;
      const hDesc = item.weather?.[0]?.description || "Clear";
      hourlyForecasts.push({
        time: timeStr,
        temp: item.main.temp,
        weatherCode: openWeatherIdToWMO(wId),
        description: hDesc.charAt(0).toUpperCase() + hDesc.slice(1),
        rainChance: Math.round((item.pop || 0) * 100)
      });
    }

    // Daily Forecasts (Grouping 40 items)
    const dailyMap: Record<string, {
      temps: number[],
      pops: number[],
      codes: number[],
      descriptions: string[],
      dateObj: Date
    }> = {};

    for (const item of fc.list || []) {
      const date = new Date(item.dt * 1000);
      const dayStr = date.toDateString();
      if (!dailyMap[dayStr]) {
        dailyMap[dayStr] = { temps: [], pops: [], codes: [], descriptions: [], dateObj: date };
      }
      dailyMap[dayStr].temps.push(item.main.temp);
      dailyMap[dayStr].pops.push(item.pop || 0);
      if (item.weather?.[0]) {
        dailyMap[dayStr].codes.push(item.weather[0].id);
        dailyMap[dayStr].descriptions.push(item.weather[0].description);
      }
    }

    const dailyForecasts = Object.values(dailyMap).map((dayData) => {
      const tempMax = Math.max(...dayData.temps);
      const tempMin = Math.min(...dayData.temps);
      const maxPop = Math.max(...dayData.pops) * 100;
      
      const idx = Math.floor(dayData.codes.length / 2);
      const code = dayData.codes[idx] || 800;
      const description = dayData.descriptions[idx] || "Clear";
      const wmoCode = openWeatherIdToWMO(code);
      const dUvIndex = estimateUVIndex(tempMax, code);

      return {
        date: dayData.dateObj.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }),
        tempMax: Math.round(tempMax * 10) / 10,
        tempMin: Math.round(tempMin * 10) / 10,
        weatherCode: wmoCode,
        description: description.charAt(0).toUpperCase() + description.slice(1),
        rainChance: Math.round(maxPop),
        uvIndex: dUvIndex
      };
    }).slice(0, 7); // Max 7 days

    // Dynamic Alerts based on live thresholds
    const alerts = [];
    if (current.uvIndex >= 8) {
      alerts.push({
        title: "Extreme UV Warning",
        description: "The UV index is extremely high today. Seek shade, wear protective clothing, and apply SPF 30+ sunscreen every 2 hours.",
        severity: "severe",
        time: "Today"
      });
    }
    if (current.windSpeed >= 30) {
      alerts.push({
        title: "High Wind Alert",
        description: "Strong winds are active. Secure loose outdoor objects and exercise caution while driving high-profile vehicles.",
        severity: "moderate",
        time: "Active"
      });
    }
    if (current.rainChance >= 80 && current.description.toLowerCase().includes("rain")) {
      alerts.push({
        title: "Heavy Rainfall Expected",
        description: "Heavy rain is highly probable. Driving visibility may be limited and streets could accumulate water quickly.",
        severity: "moderate",
        time: "Upcoming"
      });
    }
    if (aqi > 100) {
      alerts.push({
        title: "Poor Air Quality Advisory",
        description: "Air pollution levels are unhealthy. Sensitive individuals should limit prolonged outdoor exertion.",
        severity: "moderate",
        time: "Today"
      });
    }
    if (current.temp > 35) {
      alerts.push({
        title: "Excessive Heat Warning",
        description: "Dangerously hot conditions are present. Drink plenty of fluids, stay in air-conditioned spaces, and avoid outdoor exercise.",
        severity: "severe",
        time: "Active"
      });
    }

    return {
      city: cityName,
      lat,
      lon,
      current,
      hourly: hourlyForecasts,
      daily: dailyForecasts,
      alerts,
      dataSource: "OpenWeatherMap"
    };
  } catch (error: any) {
    // Suppress console error noise and gracefully fallback to Open-Meteo provider
    return await fetchOpenMeteoFallback(lat, lon, cityName);
  }
}

// 2. Weather Fetch API
app.get("/api/weather", async (req: Request, res: Response) => {
  const lat = req.query.lat ? parseFloat(req.query.lat as string) : 37.7749;
  const lon = req.query.lon ? parseFloat(req.query.lon as string) : -122.4194;
  const cityName = (req.query.city as string) || "San Francisco";

  try {
    const payload = await fetchWeatherPipeline(lat, lon, cityName);

    // Save retrieval to database history for analytics (keep last 35 logs)
    const db = readDB();
    const newRecord: HistoricalLog = {
      id: `hist-${Date.now()}`,
      timestamp: new Date().toISOString(),
      city: cityName,
      temp: payload.current.temp,
      humidity: payload.current.humidity,
      rainChance: payload.current.rainChance,
      windSpeed: payload.current.windSpeed,
      aqi: payload.current.airQuality
    };
    db.history.unshift(newRecord);
    if (db.history.length > 35) {
      db.history = db.history.slice(0, 35);
    }
    writeDB(db);

    res.json(payload);
  } catch (error: any) {
    console.error("Weather fetching error:", error);
    res.status(500).json({ error: "Failed to fetch weather forecast data" });
  }
});

// 3. User Preferences Endpoints
app.get("/api/preferences", (req: Request, res: Response) => {
  const db = readDB();
  res.json(db.preferences);
});

app.post("/api/preferences", (req: Request, res: Response) => {
  const db = readDB();
  db.preferences = { ...db.preferences, ...req.body };
  writeDB(db);
  res.json({ success: true, preferences: db.preferences });
});

// 4. Saved Locations Endpoints
app.get("/api/locations", (req: Request, res: Response) => {
  const db = readDB();
  res.json(db.savedLocations);
});

app.post("/api/locations", (req: Request, res: Response) => {
  const db = readDB();
  const { city, lat, lon } = req.body;
  
  if (!city || lat === undefined || lon === undefined) {
    res.status(400).json({ error: "Missing city name or coordinates" });
    return;
  }

  // Avoid duplicates
  const exists = db.savedLocations.some(
    loc => loc.city.toLowerCase() === city.toLowerCase() || 
    (Math.abs(loc.lat - lat) < 0.05 && Math.abs(loc.lon - lon) < 0.05)
  );

  if (!exists) {
    db.savedLocations.push({ city, lat, lon });
    writeDB(db);
  }

  res.json({ success: true, savedLocations: db.savedLocations });
});

app.delete("/api/locations", (req: Request, res: Response) => {
  const db = readDB();
  const city = req.query.city as string;

  if (!city) {
    res.status(400).json({ error: "City name parameter is required" });
    return;
  }

  db.savedLocations = db.savedLocations.filter(
    loc => loc.city.toLowerCase() !== city.toLowerCase()
  );
  writeDB(db);

  res.json({ success: true, savedLocations: db.savedLocations });
});

// 5. History / Analytics Endpoint
app.get("/api/history", (req: Request, res: Response) => {
  const db = readDB();
  const city = req.query.city as string;
  
  if (city) {
    const filtered = db.history.filter(h => h.city.toLowerCase().includes(city.toLowerCase()));
    res.json(filtered);
  } else {
    res.json(db.history);
  }
});

// --- AI Google Gemini Services ---

// Endpoint 6: AI Chat Assistant
app.post("/api/ai/chat", async (req: Request, res: Response) => {
  const { messages, weatherData, preferences } = req.body;

  if (!messages || !Array.isArray(messages)) {
    res.status(400).json({ error: "Messages array is required" });
    return;
  }

  if (!ai) {
    // Simulated Fallback Reasoning if no Gemini API Key is active
    const lastUserMsg = messages[messages.length - 1]?.text || "";
    let simulatedResponse = "Hello! I am Clima, your AI weather companion. I am currently running in offline preview mode because no Google Gemini API Key has been configured in the Secrets panel. ";
    
    if (weatherData) {
      simulatedResponse += `Based on the simulated retrieval for ${weatherData.city}, it is currently ${weatherData.current.temp}°C and ${weatherData.current.description}. `;
      if (lastUserMsg.toLowerCase().includes("umbrella") || lastUserMsg.toLowerCase().includes("rain")) {
        simulatedResponse += weatherData.current.rainChance > 40 
          ? `With a ${weatherData.current.rainChance}% rain probability, I highly recommend carrying an umbrella!` 
          : `There is only a ${weatherData.current.rainChance}% chance of rain, so you likely won't need an umbrella.`;
      } else if (lastUserMsg.toLowerCase().includes("wear") || lastUserMsg.toLowerCase().includes("clothes")) {
        simulatedResponse += weatherData.current.temp < 15 
          ? "I recommend wearing a warm coat, layering up, or bringing a heavy jacket as temperatures are cool." 
          : "It's relatively mild, so a light jacket or t-shirt should be perfect.";
      } else {
        simulatedResponse += "Feel free to configure a Gemini API key via Settings > Secrets to unlock intelligent weather and outdoor reasoning!";
      }
    }
    res.json({ text: simulatedResponse });
    return;
  }

  try {
    const lastMessage = messages[messages.length - 1].text;
    const conversationHistory = messages.slice(0, -1).map((m: any) => 
      `${m.sender === 'user' ? 'User' : 'Assistant'}: ${m.text}`
    ).join("\n");

    const systemPrompt = `You are Clima, a Next-Generation AI Weather Assistant. You are a highly professional, friendly, and practical personal companion.
Your primary capability is contextual weather reasoning, travel, schedule, and outdoor planning. 
Instead of repeating raw weather data, explain the implications clearly based on the user's habits, schedules, and preferences.

IMPORTANT: You MUST NOT use double asterisks (**) or any markdown bold formatting in your response. Never wrap words with "**". Always write in clean, plain, elegant natural language.

=== USER PROFILE & MEMORY PREFERENCES ===
- Home/Preferred City: ${preferences?.preferredCity || 'Not set'}
- Temperature Unit: °${preferences?.tempUnit || 'C'}
- Wake-up Time: ${preferences?.wakeupTime || '07:00'}
- Work Schedule: ${preferences?.workSchedule || '09:00 - 17:00'}
- Commute Time: ${preferences?.commuteTime || '30 minutes'}
- Exercise Habits: ${preferences?.exerciseHabits || 'None specified'}
- Favorite Outdoor Activities: ${preferences?.favoriteActivities?.join(", ") || 'None specified'}
- Travel Methods: ${preferences?.travelMethods?.join(", ") || 'None specified'}
- Dislikes hot weather: ${preferences?.dislikesHot ? 'Yes' : 'No'}
- Dislikes rain: ${preferences?.dislikesRain ? 'Yes' : 'No'}
- Walk Preference: ${preferences?.walkPreference || 'flexible'}

=== CURRENT WEATHER DATA ===
- City: ${weatherData?.city || 'Unknown'}
- Temperature: ${weatherData?.current?.temp}°${preferences?.tempUnit || 'C'} (Feels like: ${weatherData?.current?.feelsLike}°${preferences?.tempUnit || 'C'})
- Condition: ${weatherData?.current?.description}
- Wind: ${weatherData?.current?.windSpeed} km/h
- Humidity: ${weatherData?.current?.humidity}%
- Rain Probability: ${weatherData?.current?.rainChance}%
- UV Index: ${weatherData?.current?.uvIndex}
- Air Quality Index (US AQI): ${weatherData?.current?.airQuality} (${weatherData?.current?.airQualityLabel})
- Sunrise: ${weatherData?.current?.sunrise}, Sunset: ${weatherData?.current?.sunset}

=== FORECAST DATA ===
Hourly Forecast (Next few hours):
${(weatherData?.hourly || []).slice(0, 6).map((h: any) => `- ${h.time}: ${h.temp}°${preferences?.tempUnit || 'C'}, ${h.description}, Rain Chance: ${h.rainChance}%`).join("\n")}

Daily Forecast:
${(weatherData?.daily || []).slice(0, 5).map((d: any) => `- ${d.date}: High ${d.tempMax}°${preferences?.tempUnit || 'C'}, Low ${d.tempMin}°${preferences?.tempUnit || 'C'}, ${d.description}, Rain Max Chance: ${d.rainChance}%`).join("\n")}

Active Alerts:
${(weatherData?.alerts || []).map((a: any) => `* [ALERT] ${a.title}: ${a.description}`).join("\n") || "No alerts active."}

Provide a natural, helpful, conversational response directly answering the user's question, applying reasoning over the weather data and their preferences. Avoid dry telemetry style, be empathetic, warm, and highly practical.`;

    const chatResponse = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        { text: systemPrompt },
        { text: conversationHistory ? `Previous conversation:\n${conversationHistory}` : "" },
        { text: `User: ${lastMessage}` }
      ]
    });

    const text = (chatResponse.text || "").replace(/\*\*/g, "");
    res.json({ text });
  } catch (error: any) {
    console.log("Chat using simulated fallback.");
    const lastUserMsg = messages[messages.length - 1]?.text || "";
    let simulatedResponse = "Hello! I am Clima, your AI weather companion. Since the AI service is currently at maximum capacity, I've enabled offline assistance. ";
    if (weatherData) {
      simulatedResponse += `Based on the latest reports for ${weatherData.city}, it is currently ${weatherData.current.temp}°C and ${weatherData.current.description}. `;
      if (lastUserMsg.toLowerCase().includes("umbrella") || lastUserMsg.toLowerCase().includes("rain")) {
        simulatedResponse += weatherData.current.rainChance > 40 
          ? `With a ${weatherData.current.rainChance}% risk of rain, keeping an umbrella close is highly recommended!` 
          : `With only a ${weatherData.current.rainChance}% risk of rain, you likely won't need an umbrella.`;
      } else if (lastUserMsg.toLowerCase().includes("wear") || lastUserMsg.toLowerCase().includes("clothes")) {
        simulatedResponse += weatherData.current.temp < 15 
          ? "I recommend warm layering or bringing along a heavy jacket for outdoor ventures." 
          : "Standard activewear or a light shirt should be perfectly comfortable.";
      } else {
        simulatedResponse += "Please let me know if you would like me to check local fitness guidelines or suggest outdoor gear suggestions based on current conditions!";
      }
    } else {
      simulatedResponse += "Please search for a city to retrieve current details and custom companion suggestions!";
    }
    res.json({ text: simulatedResponse });
  }
});

// Endpoint 7: AI Smart Insights
app.get("/api/ai/insights", async (req: Request, res: Response) => {
  const lat = req.query.lat ? parseFloat(req.query.lat as string) : 37.7749;
  const lon = req.query.lon ? parseFloat(req.query.lon as string) : -122.4194;
  const cityName = (req.query.city as string) || "San Francisco";

  const db = readDB();
  const preferences = db.preferences;

  if (!ai) {
    // Offline simulation fallback insights
    res.json({
      insights: [
        "Today's weather is moderate and perfect for standard outdoor walk schedules.",
        "Consider carrying layers today as temperatures may fluctuate from morning to evening.",
        "UV index is moderate; standard sunscreen is advisable for afternoon strolls."
      ]
    });
    return;
  }

  try {
    const weather = await fetchWeatherPipeline(lat, lon, cityName);

    const prompt = `Based on the following weather data and user habits, generate exactly 3 highly personalized, context-aware bullet points of "Smart Weather Insights" or activity recommendations (e.g., clothes, commute advice, outdoor sports, skin protection, golden hour timing). Return the insights as a clean JSON array of strings.

IMPORTANT: Do not use double asterisks (**) or any markdown formatting. Provide clean plain text strings.

User Preferences:
- Wake up: ${preferences.wakeupTime}
- Schedule: ${preferences.workSchedule}
- Exercise: ${preferences.exerciseHabits}
- Favorite activities: ${preferences.favoriteActivities.join(", ")}
- Travel style: ${preferences.travelMethods.join(", ")}
- Dislikes hot: ${preferences.dislikesHot}, Rain: ${preferences.dislikesRain}

Current Weather in ${cityName}:
- Temperature: ${weather.current.temp}°C (Feels like: ${weather.current.feelsLike}°C)
- Code: ${weather.current.weatherCode} (${weather.current.description})
- Humidity: ${weather.current.humidity}%
- UV: ${weather.current.uvIndex}
- AQI: ${weather.current.airQuality}

Make the recommendations sharp, specific, and action-oriented. Do not include any JSON wrappers or markdown styling other than a raw JSON string array.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING
          },
          description: "A list of exactly 3 weather recommendations/insights"
        }
      }
    });

    const insights = JSON.parse(response.text || "[]").map((item: string) => item.replace(/\*\*/g, ""));
    res.json({ insights });
  } catch (error: any) {
    console.log("Insights using simulated fallback.");
    res.json({
      insights: [
        "Temps are comfortable; enjoy your standard outdoor routines.",
        "Consider keeping an extra layers handy for temperature variations.",
        "Check your evening walk timings to optimize comfort levels."
      ]
    });
  }
});

// Endpoint 8: AI Daily Briefing
app.get("/api/ai/briefing", async (req: Request, res: Response) => {
  const lat = req.query.lat ? parseFloat(req.query.lat as string) : 37.7749;
  const lon = req.query.lon ? parseFloat(req.query.lon as string) : -122.4194;
  const cityName = (req.query.city as string) || "San Francisco";

  const db = readDB();
  const preferences = db.preferences;

  if (!ai) {
    res.json({
      briefing: `Good morning from Clima, your AI Companion! ☀️ Today in ${cityName}, expect comfortable conditions with temperatures reaching around ${db.history[0]?.temp || 18}°C. Excellent conditions for your day! Configure your Gemini API key in the Secrets panel to activate personalized, smart daily briefings.`
    });
    return;
  }

  try {
    const weather = await fetchWeatherPipeline(lat, lon, cityName);

    const prompt = `You are Clima, a personalized AI Weather Companion. Write a personalized "Good morning!" weather briefing summarizing the day's conditions for ${cityName}, and plan it around the user's daily habits, work schedules, commute, and exercise routines. Keep it highly engaging, practical, warm, and between 100-140 words.

IMPORTANT: You MUST NOT use double asterisks (**) or any markdown bold formatting in your response. Never wrap words with "**". Always write in clean, plain, elegant natural language.

User Profile:
- Wake up: ${preferences.wakeupTime}
- Work: ${preferences.workSchedule}
- Exercise: ${preferences.exerciseHabits}
- Favorite hobbies: ${preferences.favoriteActivities.join(", ")}
- Preferred travel: ${preferences.travelMethods.join(", ")}
- Walks: ${preferences.walkPreference} walks

Weather today in ${cityName}:
- Current: ${weather.current.temp}°C (${weather.current.description})
- Daily High: ${weather.current.high}°C, Low: ${weather.current.low}°C
- Precipitation risk max: ${weather.current.rainChance}%
- UV peak: ${weather.current.uvIndex}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt
    });

    const briefing = (response.text || "").replace(/\*\*/g, "");
    res.json({ briefing });
  } catch (error: any) {
    console.log("Briefing using simulated fallback.");
    const db = readDB();
    res.json({
      briefing: `Good morning from Clima, your AI Companion! ☀️ Today in ${cityName}, expect temperature levels around ${db.history[0]?.temp || 18}°C. Excellent weather for standard active schedules! Offline planning modes are temporarily active to guarantee seamless access.`
    });
  }
});

// Endpoint 9: AI Custom Planner
app.post("/api/ai/plan", async (req: Request, res: Response) => {
  const { activity, weatherData, preferences } = req.body;

  if (!activity) {
    res.status(400).json({ error: "Activity name is required for planning" });
    return;
  }

  if (!ai) {
    // Simulation fallback plan
    res.json({
      plan: {
        activity,
        bestDay: "Saturday",
        recommendation: `This is a preview recommendation. For the selected activity '${activity}', Saturday afternoon appears to have the most favorable conditions with minimal cloud cover and light winds.`,
        timeline: [
          { time: "Morning", weather: "Sunny, 16°C", rating: "Excellent", tips: "Perfect light breeze, dress in standard layers." },
          { time: "Afternoon", weather: "Clear, 21°C", rating: "Excellent", tips: "Temperatures peak. Wear sunscreen and stay hydrated." },
          { time: "Evening", weather: "Cool, 14°C", rating: "Good", tips: "Slight offshore breeze starting, fetch a windbreaker." }
        ],
        packingSuggestions: ["Sunscreen SPF 30+", "Water bottle (1.5L)", "Comfortable shoes", "Light jacket"]
      }
    });
    return;
  }

  try {
    const prompt = `You are Clima, an intelligent activity weather planner. Create a custom weather suitability report and timeline plan for the activity "${activity}" over the next few days, based on the following forecast and user preferences.

IMPORTANT: Do not use double asterisks (**) or any markdown formatting in any of the returned text or JSON fields. Provide clean plain text strings.

User Profile:
- Temp Unit: °${preferences?.tempUnit || 'C'}
- Preferred activities: ${preferences?.favoriteActivities?.join(", ") || "none specified"}

Weather Forecast for planning:
- Current City: ${weatherData?.city || "Unknown"}
- Daily conditions:
${(weatherData?.daily || []).map((d: any) => `- ${d.date}: High ${d.tempMax}, Low ${d.tempMin}, ${d.description}, Rain: ${d.rainChance}%`).join("\n")}

Respond strictly in JSON format matching the ActivityPlan structure:
{
  "activity": "Activity name",
  "bestDay": "Which day of the week is best and why",
  "recommendation": "Overall detailed assistant planning recommendation paragraph",
  "timeline": [
    { "time": "Morning / Afternoon / Evening", "weather": "Conditions summary", "rating": "Excellent / Good / Fair / Poor", "tips": "Practical tip" }
  ],
  "packingSuggestions": ["List of critical clothing/gear items to carry"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            activity: { type: Type.STRING },
            bestDay: { type: Type.STRING },
            recommendation: { type: Type.STRING },
            timeline: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  time: { type: Type.STRING },
                  weather: { type: Type.STRING },
                  rating: { type: Type.STRING },
                  tips: { type: Type.STRING }
                },
                required: ["time", "weather", "rating", "tips"]
              }
            },
            packingSuggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["activity", "bestDay", "recommendation", "timeline", "packingSuggestions"]
        }
      }
    });

    const parsedPlan = JSON.parse(response.text || "{}");
    if (parsedPlan.bestDay) parsedPlan.bestDay = parsedPlan.bestDay.replace(/\*\*/g, "");
    if (parsedPlan.recommendation) parsedPlan.recommendation = parsedPlan.recommendation.replace(/\*\*/g, "");
    if (parsedPlan.timeline && Array.isArray(parsedPlan.timeline)) {
      parsedPlan.timeline = parsedPlan.timeline.map((item: any) => ({
        ...item,
        weather: (item.weather || "").replace(/\*\*/g, ""),
        tips: (item.tips || "").replace(/\*\*/g, "")
      }));
    }
    if (parsedPlan.packingSuggestions && Array.isArray(parsedPlan.packingSuggestions)) {
      parsedPlan.packingSuggestions = parsedPlan.packingSuggestions.map((item: string) => item.replace(/\*\*/g, ""));
    }
    res.json({ plan: parsedPlan });
  } catch (error: any) {
    console.log("Planner using simulated fallback.");
    res.json({
      plan: {
        activity,
        bestDay: "Upcoming Weekend",
        recommendation: `Offline planning parameters are currently active. For '${activity}', the upcoming weekend afternoon appears to have favorable local conditions for outdoor activities based on typical conditions.`,
        timeline: [
          { time: "Morning", weather: "Clear, 16°C", rating: "Excellent", tips: "Perfect light breeze, dress in standard layers." },
          { time: "Afternoon", weather: "Comfortable, 21°C", rating: "Excellent", tips: "Temperatures peak. Wear sunscreen and stay hydrated." },
          { time: "Evening", weather: "Cooling, 14°C", rating: "Good", tips: "Slight offshore breeze starting, fetch a windbreaker." }
        ],
        packingSuggestions: ["Sunscreen SPF 30+", "Water bottle (1.5L)", "Comfortable shoes", "Light jacket"]
      }
    });
  }
});


// --- Serve Static Assets / Integrate Vite Dev Middleware ---

const isProd = process.env.NODE_ENV === "production";

async function start() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

start();
