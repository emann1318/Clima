export interface WeatherPreferences {
  preferredCity: string;
  tempUnit: 'C' | 'F';
  wakeupTime: string;
  workSchedule: string;
  commuteTime: string;
  exerciseHabits: string;
  favoriteActivities: string[];
  travelMethods: string[];
  dislikesHot: boolean;
  dislikesRain: boolean;
  walkPreference: 'morning' | 'evening' | 'flexible';
}

export interface CurrentWeather {
  temp: number;
  feelsLike: number;
  high: number;
  low: number;
  weatherCode: number;
  description: string;
  humidity: number;
  windSpeed: number;
  windDirection: number;
  pressure: number;
  uvIndex: number;
  airQuality: number; // AQI index 1-5 (1: Good, 5: Very Poor)
  airQualityLabel: string;
  sunrise: string;
  sunset: string;
  rainChance: number;
  visibility: number; // in km
}

export interface HourlyForecast {
  time: string;
  temp: number;
  weatherCode: number;
  description: string;
  rainChance: number;
}

export interface DailyForecast {
  date: string;
  tempMax: number;
  tempMin: number;
  weatherCode: number;
  description: string;
  rainChance: number;
  uvIndex: number;
}

export interface WeatherAlert {
  title: string;
  description: string;
  severity: 'minor' | 'moderate' | 'severe';
  time: string;
}

export interface WeatherData {
  city: string;
  lat: number;
  lon: number;
  current: CurrentWeather;
  hourly: HourlyForecast[];
  daily: DailyForecast[];
  alerts: WeatherAlert[];
  dataSource?: string;
}

export interface HistoricalRecord {
  id: string;
  timestamp: string;
  city: string;
  temp: number;
  humidity: number;
  rainChance: number;
  windSpeed: number;
  aqi: number;
}

export interface SavedLocation {
  city: string;
  lat: number;
  lon: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export interface ActivityPlan {
  activity: string;
  bestDay: string;
  recommendation: string;
  timeline: { time: string; weather: string; rating: 'Excellent' | 'Good' | 'Fair' | 'Poor'; tips: string }[];
  packingSuggestions: string[];
}
