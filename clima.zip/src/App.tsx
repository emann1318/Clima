/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  CloudSun, 
  Search, 
  MapPin, 
  Heart, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  Sparkles,
  Layers,
  Settings,
  HelpCircle,
  Clock,
  Compass,
  Plus,
  Trash2
} from "lucide-react";
import { WeatherData, WeatherPreferences, SavedLocation } from "./types";
import WeatherDashboard from "./components/WeatherDashboard";
import AIChatPanel from "./components/AIChatPanel";
import InteractiveMap from "./components/InteractiveMap";
import PreferencesModal from "./components/PreferencesModal";
import DailyBriefing from "./components/DailyBriefing";
import AIPlanner from "./components/AIPlanner";
import HistoricalAnalytics from "./components/HistoricalAnalytics";

export default function App() {
  // Application State
  const [activeCoords, setActiveCoords] = useState<{ lat: number; lon: number; city: string }>({
    lat: 37.7749,
    lon: -122.4194,
    city: "San Francisco"
  });
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [preferences, setPreferences] = useState<WeatherPreferences | null>(null);
  const [savedLocations, setSavedLocations] = useState<SavedLocation[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [showPrefs, setShowPrefs] = useState(false);

  // 1. Load User Preferences and Saved Locations on Startup
  useEffect(() => {
    async function loadInitialData() {
      try {
        // Load preferences
        const prefRes = await fetch("/api/preferences");
        const prefData = await prefRes.json();
        setPreferences(prefData);
        
        if (prefData?.preferredCity) {
          // Resolve coordinates for the preferred home city
          const geoRes = await fetch(`/api/geocode?q=${encodeURIComponent(prefData.preferredCity)}`);
          const geoData = await geoRes.json();
          if (geoData && geoData.length > 0) {
            setActiveCoords({
              lat: geoData[0].lat,
              lon: geoData[0].lon,
              city: geoData[0].city
            });
          }
        }
      } catch (err) {
        console.error("Error loading initial data:", err);
      }

      // Load saved favorites
      try {
        const locRes = await fetch("/api/locations");
        const locData = await locRes.json();
        setSavedLocations(locData || []);
      } catch (err) {
        console.error("Error loading locations:", err);
      }
    }

    loadInitialData();
  }, []);

  // 2. Fetch Weather when Coordinates Change or Manual Refresh is triggered
  useEffect(() => {
    async function fetchWeather() {
      setIsLoadingWeather(true);
      try {
        const res = await fetch(`/api/weather?lat=${activeCoords.lat}&lon=${activeCoords.lon}&city=${encodeURIComponent(activeCoords.city)}`);
        const data = await res.json();
        if (data && !data.error) {
          setWeather(data);
        }
      } catch (err) {
        console.error("Error fetching weather payload:", err);
      } finally {
        setIsLoadingWeather(false);
      }
    }

    if (activeCoords) {
      fetchWeather();
    }
  }, [activeCoords, refreshTrigger]);

  // 3. Geocoding Search handler
  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (searchQuery.trim().length > 2) {
        setIsSearching(true);
        try {
          const res = await fetch(`/api/geocode?q=${encodeURIComponent(searchQuery)}`);
          const data = await res.json();
          setSearchResults(data || []);
        } catch (err) {
          console.error("Geocoding search failed:", err);
        } finally {
          setIsSearching(false);
        }
      } else {
        setSearchResults([]);
      }
    }, 400);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  // Save/Update user preferences
  const handleSavePreferences = async (newPrefs: Partial<WeatherPreferences>) => {
    try {
      const res = await fetch("/api/preferences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPrefs)
      });
      const data = await res.json();
      if (data.success) {
        setPreferences(data.preferences);
        setRefreshTrigger(prev => prev + 1); // trigger refresh to update AI outputs
      }
    } catch (err) {
      console.error("Failed to save preferences:", err);
    }
  };

  // Add active location as favorite
  const handleAddFavorite = async () => {
    if (!activeCoords) return;
    try {
      const res = await fetch("/api/locations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          city: activeCoords.city,
          lat: activeCoords.lat,
          lon: activeCoords.lon
        })
      });
      const data = await res.json();
      if (data.savedLocations) {
        setSavedLocations(data.savedLocations);
      }
    } catch (err) {
      console.error("Failed to save favorite:", err);
    }
  };

  // Remove a favorite city
  const handleRemoveFavorite = async (cityName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/locations?city=${encodeURIComponent(cityName)}`, {
        method: "DELETE"
      });
      const data = await res.json();
      if (data.savedLocations) {
        setSavedLocations(data.savedLocations);
      }
    } catch (err) {
      console.error("Failed to delete favorite:", err);
    }
  };

  // GPS Auto-Detection handler
  const handleGPSDetect = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          setIsLoadingWeather(true);
          try {
            // Fetch reverse geocoded city name from open-meteo search
            // (or fallback to generic lat/lon string)
            const queryName = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
            setActiveCoords({
              lat: latitude,
              lon: longitude,
              city: `GPS Location (${queryName})`
            });
          } catch (_) {
            setActiveCoords({
              lat: latitude,
              lon: longitude,
              city: "My GPS Location"
            });
          }
        },
        (error) => {
          alert(`Geolocation lookup failed: ${error.message}. Please enable location permissions in browser.`);
        }
      );
    } else {
      alert("GPS Geolocation is not supported by your browser.");
    }
  };

  return (
    <div className="min-h-screen text-slate-100 flex flex-col" id="app-root-container">
      
      {/* Dynamic Header */}
      <header className="glass-panel rounded-none border-t-0 border-x-0 border-b border-white/10 px-6 py-4 flex items-center justify-between shrink-0 sticky top-0 z-50 bg-slate-950/40 backdrop-blur-md" id="app-header">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 rounded-xl border border-indigo-500/30 text-indigo-400 shadow-[0_0_12px_rgba(99,102,241,0.2)]">
            <CloudSun size={24} className="animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-bold font-display tracking-tight text-white flex items-center gap-2">
              Clima <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">AI companion</span>
            </h1>
            <p className="text-[10px] text-slate-400 font-mono">Next-Generation Intelligent Weather Assistant</p>
          </div>
        </div>

        {/* Global actions */}
        <div className="flex items-center gap-2.5" id="header-global-actions">
          <button
            onClick={() => setRefreshTrigger(prev => prev + 1)}
            className="p-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded-lg text-slate-300 transition-all active:scale-95 flex items-center gap-1 text-xs"
            title="Refresh weather data"
            id="btn-header-refresh"
          >
            <RefreshCw size={14} className={isLoadingWeather ? "animate-spin text-indigo-400" : ""} />
            <span className="hidden sm:inline">Sync</span>
          </button>
          
          <button
            onClick={() => setShowPrefs(!showPrefs)}
            className={`p-2 border rounded-lg transition-all active:scale-95 flex items-center gap-1 text-xs ${
              showPrefs 
                ? "bg-indigo-500 border-indigo-400 text-slate-950 font-bold shadow-[0_0_12px_rgba(99,102,241,0.3)]" 
                : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
            }`}
            id="btn-header-prefs"
          >
            <Settings size={14} />
            <span className="hidden sm:inline">{showPrefs ? "Dashboard" : "Memory"}</span>
          </button>
        </div>
      </header>

      {/* Main Grid Workspace */}
      <main className="flex-grow p-4 md:p-6 max-w-7xl mx-auto w-full flex flex-col gap-6" id="app-main-workspace">
        
        {/* Loading placeholder banner */}
        {isLoadingWeather && !weather && (
          <div className="flex-grow flex flex-col items-center justify-center gap-3 py-20" id="main-global-loader">
            <RefreshCw className="animate-spin text-indigo-400" size={32} />
            <span className="text-sm font-mono text-slate-400">Loading dynamic weather metrics...</span>
          </div>
        )}

        {weather && preferences && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="app-columns-grid">
            
            {/* Column 1: Left Control Hub (3 cols) */}
            <div className="lg:col-span-3 flex flex-col gap-6" id="col-hub-left">
              
              {/* Location Search card */}
              <div className="glass-panel p-4 flex flex-col gap-4 relative" id="card-location-search">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Location Search</span>
                
                <div className="flex gap-2 relative">
                  <div className="relative flex-grow">
                    <Search className="absolute left-3 top-2.5 text-slate-400" size={15} />
                    <input
                      type="text"
                      placeholder="Search global city..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="glass-input pl-9 text-xs w-full py-2"
                      id="input-city-search"
                    />
                  </div>
                  <button
                    onClick={handleGPSDetect}
                    className="p-2 bg-white/5 border border-white/10 hover:bg-white/10 text-indigo-400 hover:text-indigo-300 rounded-lg transition-all active:scale-95 shrink-0"
                    title="Detect current GPS location"
                    id="btn-gps-detect"
                  >
                    <MapPin size={16} />
                  </button>
                </div>

                {/* Suggestions List Dropdown */}
                {searchResults.length > 0 && (
                  <div className="absolute top-16 left-4 right-4 bg-slate-900/95 backdrop-blur-lg border border-white/15 rounded-xl p-2 z-20 flex flex-col gap-1 shadow-2xl" id="search-dropdown-suggestions">
                    {searchResults.map((res, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setActiveCoords({ lat: res.lat, lon: res.lon, city: res.city });
                          setSearchQuery("");
                          setSearchResults([]);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 transition-all text-xs text-white"
                        id={`btn-suggest-${idx}`}
                      >
                        {res.city}
                      </button>
                    ))}
                  </div>
                )}
                {isSearching && (
                  <div className="absolute top-16 left-4 right-4 bg-slate-900 border border-white/10 rounded-xl p-3 z-20 text-center text-xs font-mono text-slate-400 flex items-center justify-center gap-2">
                    <RefreshCw className="animate-spin text-indigo-400" size={12} />
                    <span>Resolving global coordinates...</span>
                  </div>
                )}

                {/* Favorites saved locations */}
                <div className="flex flex-col gap-2 mt-2" id="favorites-section">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Saved Cities</span>
                    <button
                      onClick={handleAddFavorite}
                      className="text-[10px] bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20 px-2.5 py-1 rounded-md border border-indigo-500/20 font-bold transition-all flex items-center gap-1"
                      id="btn-add-favorite"
                    >
                      <Plus size={10} /> Add Current
                    </button>
                  </div>

                  <div className="flex flex-col gap-1.5 max-h-40 overflow-y-auto pr-1" id="favorites-list">
                    {savedLocations.length === 0 ? (
                      <span className="text-[11px] text-slate-500 italic py-2">No favorites bookmarked yet.</span>
                    ) : (
                      savedLocations.map((loc, idx) => (
                        <div
                          key={idx}
                          onClick={() => setActiveCoords({ lat: loc.lat, lon: loc.lon, city: loc.city })}
                          className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                            activeCoords.city.toLowerCase() === loc.city.toLowerCase()
                              ? "bg-indigo-500/10 border-indigo-500/40 text-white"
                              : "bg-white/5 border-white/5 hover:bg-white/10 text-slate-300"
                          }`}
                          id={`favorite-row-${idx}`}
                        >
                          <span className="font-medium truncate pr-2">{loc.city}</span>
                          <button
                            onClick={(e) => handleRemoveFavorite(loc.city, e)}
                            className="p-1 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 rounded transition-all shrink-0"
                            title="Remove from favorites"
                            id={`btn-remove-fav-${idx}`}
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

              </div>

              {/* Memory Habits Panel */}
              <PreferencesModal preferences={preferences} onSave={handleSavePreferences} />

              {/* Daily AI Briefing */}
              <DailyBriefing weather={weather} triggerRefresh={refreshTrigger} />

            </div>

            {/* Column 2: Dashboard Bento and Maps (6 cols) */}
            <div className="lg:col-span-6 flex flex-col gap-6" id="col-workspace-middle">
              
              {showPrefs ? (
                /* Overlay Preference Settings Fullview in middle if open */
                <div className="flex flex-col gap-6 animate-fade-in" id="dashboard-settings-overlay">
                  <div className="glass-panel p-6" id="settings-overlay-box">
                    <h2 className="text-xl font-extrabold font-display tracking-tight text-white">Full Settings Dashboard</h2>
                    <p className="text-xs text-slate-400 mt-0.5 mb-6">Modify user profile, wakeup parameters and preferred schedules</p>
                    <PreferencesModal preferences={preferences} onSave={handleSavePreferences} />
                  </div>
                </div>
              ) : (
                /* Normal bento dashboard, map, charts and planner */
                <>
                  {/* Apple Weather-like Bento Dashboard */}
                  <WeatherDashboard weather={weather} preferences={preferences} />

                  {/* Interactive simulated radar weather map */}
                  <InteractiveMap weather={weather} />

                  {/* History analytics graph charts */}
                  <HistoricalAnalytics city={weather.city} preferences={preferences} refreshTrigger={refreshTrigger} />

                  {/* AI Activity & travel Planner */}
                  <AIPlanner weather={weather} preferences={preferences} />
                </>
              )}

            </div>

            {/* Column 3: AI Chat Reasoning Panel (3 cols) */}
            <div className="lg:col-span-3 flex flex-col gap-6" id="col-assistant-right">
              
              {/* Permanent interactive sidebar chatbot reasoning engine */}
              <AIChatPanel weather={weather} preferences={preferences} />

              {/* Quick companion guide info */}
              <div className="glass-panel p-4 text-[11px] leading-relaxed text-slate-400" id="chat-metadata-info">
                <span className="font-bold text-slate-300 font-display block mb-1">Interactive Handlers</span>
                <p>Clima combines active atmospheric curves directly with your custom schedules and workout routines to synthesize smart advice.</p>
                <div className="flex items-center gap-3 mt-3 pt-3 border-t border-white/5 font-mono text-[9px] text-indigo-400">
                  <span>STT: Web Speech Capture</span>
                  <span>TTS: SpeechSynthesis</span>
                </div>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* Styled Footer */}
      <footer className="glass-panel rounded-none border-b-0 border-x-0 border-t border-white/15 px-6 py-4 mt-auto text-center text-[10px] font-mono text-slate-500 shrink-0" id="app-footer">
        <span>© 2026 Clima Systems. Grounded utilizing Google Gemini 3.5 & Open-Meteo Geocoding. Built in full compliance with the core AI Studio guidelines.</span>
      </footer>

    </div>
  );
}
