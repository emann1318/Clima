import React from "react";
import { 
  Sun, 
  CloudSun, 
  Cloud, 
  CloudDrizzle, 
  CloudRain, 
  CloudLightning, 
  Snowflake, 
  CloudFog,
  HelpCircle
} from "lucide-react";

interface WeatherIconProps {
  code: number;
  className?: string;
  size?: number;
}

export default function WeatherIcon({ code, className = "", size = 24 }: WeatherIconProps) {
  // Map WMO codes to Lucide icons
  const getIcon = () => {
    switch (code) {
      case 0:
        return <Sun size={size} className={`text-amber-400 animate-pulse ${className}`} id={`icon-sun-${code}`} />;
      case 1:
      case 2:
        return <CloudSun size={size} className={`text-amber-200 ${className}`} id={`icon-cloudsun-${code}`} />;
      case 3:
        return <Cloud size={size} className={`text-slate-300 ${className}`} id={`icon-cloud-${code}`} />;
      case 45:
      case 48:
        return <CloudFog size={size} className={`text-slate-400 ${className}`} id={`icon-fog-${code}`} />;
      case 51:
      case 53:
      case 55:
      case 56:
      case 57:
        return <CloudDrizzle size={size} className={`text-sky-300 ${className}`} id={`icon-drizzle-${code}`} />;
      case 61:
      case 63:
      case 80:
      case 81:
        return <CloudRain size={size} className={`text-sky-400 ${className}`} id={`icon-rain-${code}`} />;
      case 65:
      case 66:
      case 67:
      case 82:
      case 95:
      case 96:
      case 99:
        return <CloudLightning size={size} className={`text-indigo-400 animate-bounce ${className}`} id={`icon-lightning-${code}`} />;
      case 71:
      case 73:
      case 75:
      case 77:
      case 85:
      case 86:
        return <Snowflake size={size} className={`text-blue-200 animate-spin-slow ${className}`} id={`icon-snow-${code}`} />;
      default:
        return <HelpCircle size={size} className={`text-slate-400 ${className}`} id={`icon-unknown-${code}`} />;
    }
  };

  return <span className="inline-flex items-center justify-center">{getIcon()}</span>;
}
