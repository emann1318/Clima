import React, { useState, useEffect, useRef } from "react";
import { Send, Sparkles, Mic, MicOff, RefreshCw, Volume2, VolumeX, User, HelpCircle } from "lucide-react";
import { ChatMessage, WeatherData, WeatherPreferences } from "../types";

interface AIChatPanelProps {
  weather: WeatherData;
  preferences: WeatherPreferences;
}

export default function AIChatPanel({ weather, preferences }: AIChatPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-1",
      sender: "assistant",
      text: "Hello! I am your AI Weather Companion. Ask me anything, like: 'Should I bring an umbrella?' or 'Is tonight good for running?'",
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Speech Recognition setup (STT)
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = "en-US";

      rec.onstart = () => {
        setIsListening(true);
      };

      rec.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        setInputText(text);
      };

      rec.onerror = (e: any) => {
        console.error("Speech recognition error:", e);
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  const handleMicToggle = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in this browser. Try Chrome, Edge, or Safari.");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
    }
  };

  // TTS helper
  const speakText = (text: string) => {
    if (!isVoiceEnabled || typeof window === "undefined" || !window.speechSynthesis) return;
    
    // Stop any ongoing speech
    window.speechSynthesis.cancel();
    
    // Clean text of markdowns
    const cleanText = text.replace(/[^\w\s.,?!'"]/gi, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    window.speechSynthesis.speak(utterance);
  };

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: new Date().toISOString()
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          weatherData: weather,
          preferences
        })
      });
      const data = await res.json();
      
      const assistantMsg: ChatMessage = {
        id: `assist-${Date.now()}`,
        sender: "assistant",
        text: (data.text || "I apologize, I could not complete that reasoning. Please retry.").replace(/\*\*/g, ""),
        timestamp: new Date().toISOString()
      };

      setMessages((prev) => [...prev, assistantMsg]);
      speakText(assistantMsg.text);
    } catch (err) {
      console.error("AI chat error:", err);
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: "assistant",
          text: "I ran into an issue communicating with the core brains. Please verify your connection or secrets.",
          timestamp: new Date().toISOString()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  const quickChips = [
    "Should I carry an umbrella today?",
    "Is today a good day for jogging?",
    "What clothes should I wear?",
    "Should I postpone my picnic?",
    "Will it rain before I leave work?",
    "When is the best time today to go out?"
  ];

  return (
    <div className="glass-panel p-5 flex flex-col h-[520px]" id="ai-chat-root">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3 shrink-0" id="chat-header">
        <div className="flex items-center gap-2">
          <Sparkles className="text-indigo-400 animate-pulse" size={18} />
          <div>
            <h3 className="text-sm font-bold font-display tracking-tight text-white">Clima AI Chat</h3>
            <p className="text-[10px] text-slate-400 font-mono">Context-Aware Reasoning</p>
          </div>
        </div>

        {/* TTS Toggle Button */}
        <button
          onClick={() => {
            const nextVal = !isVoiceEnabled;
            setIsVoiceEnabled(nextVal);
            if (!nextVal && typeof window !== "undefined") {
              window.speechSynthesis.cancel();
            }
          }}
          className={`p-1.5 rounded-full border transition-all ${
            isVoiceEnabled 
              ? "bg-indigo-500/20 border-indigo-400 text-indigo-200" 
              : "bg-white/5 border-white/10 text-slate-400 hover:text-slate-200"
          }`}
          title={isVoiceEnabled ? "Mute automatic vocal answers" : "Enable automatic vocal answers"}
          id="btn-toggle-voice"
        >
          {isVoiceEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
        </button>
      </div>

      {/* Messages viewport */}
      <div className="flex-grow overflow-y-auto pr-1 flex flex-col gap-3 min-h-0 mb-3" id="chat-messages-container">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex flex-col max-w-[85%] ${
              msg.sender === "user" ? "self-end items-end" : "self-start items-start"
            }`}
            id={`chat-bubble-${msg.id}`}
          >
            <div className={`p-3 rounded-2xl text-xs leading-relaxed ${
              msg.sender === "user" 
                ? "bg-indigo-600 text-white font-medium rounded-tr-none shadow-[0_0_12px_rgba(99,102,241,0.3)]" 
                : "bg-white/5 border border-white/10 text-slate-100 rounded-tl-none"
            }`}>
              {msg.text.replace(/\*\*/g, "")}
            </div>
            <span className="text-[9px] text-slate-500 font-mono mt-1 px-1">
              {msg.sender === "user" ? "You" : "Clima"} • {new Date(msg.timestamp).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
            </span>
          </div>
        ))}
        {isLoading && (
          <div className="self-start flex items-center gap-2 text-xs text-slate-400 font-mono bg-white/5 p-2.5 rounded-2xl rounded-tl-none border border-white/10 animate-pulse" id="chat-loading-bubble">
            <RefreshCw className="animate-spin text-indigo-400" size={12} />
            <span>AI weather assistant reasoning...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompt Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-2 shrink-0 border-t border-white/5 pt-2" id="chat-quick-chips">
        {quickChips.map((chip) => (
          <button
            key={chip}
            onClick={() => handleSendMessage(chip)}
            disabled={isLoading}
            className="px-2.5 py-1 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-[10px] text-slate-300 transition-all font-sans whitespace-nowrap active:scale-95 shrink-0"
            id={`chip-${chip.toLowerCase().replace(/[^a-z0-9]/g, "-")}`}
          >
            {chip}
          </button>
        ))}
      </div>

      {/* Input controls form */}
      <form onSubmit={handleFormSubmit} className="flex gap-2 shrink-0 pt-2 border-t border-white/10" id="chat-input-form">
        <button
          type="button"
          onClick={handleMicToggle}
          className={`w-9 h-9 rounded-lg border flex items-center justify-center transition-all ${
            isListening 
              ? "bg-rose-500 border-rose-400 text-white animate-pulse" 
              : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
          }`}
          title={isListening ? "Listening... click to stop" : "Speak to your assistant"}
          id="btn-mic-toggle"
        >
          {isListening ? <MicOff size={16} /> : <Mic size={16} />}
        </button>

        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={isListening ? "Listening..." : "Type weather question..."}
          disabled={isLoading || isListening}
          className="glass-input text-xs flex-grow"
          id="input-chat-query"
        />

        <button
          type="submit"
          disabled={isLoading || !inputText.trim()}
          className="w-9 h-9 bg-indigo-500 hover:bg-indigo-400 text-white font-bold rounded-lg flex items-center justify-center active:scale-95 disabled:opacity-50 transition-all shadow-[0_0_12px_rgba(99,102,241,0.3)]"
          id="btn-chat-send"
        >
          <Send size={15} />
        </button>
      </form>

    </div>
  );
}
