import React, { useState } from "react";
import { Save, User, Clock, ShieldAlert, Heart, RefreshCw } from "lucide-react";
import { WeatherPreferences } from "../types";

interface PreferencesModalProps {
  preferences: WeatherPreferences;
  onSave: (prefs: Partial<WeatherPreferences>) => Promise<void>;
}

export default function PreferencesModal({ preferences, onSave }: PreferencesModalProps) {
  const [formData, setFormData] = useState<WeatherPreferences>({ ...preferences });
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<"idle" | "success" | "error">("idle");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData((prev) => ({ ...prev, [name]: checked }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleArrayChange = (name: 'favoriteActivities' | 'travelMethods', value: string, checked: boolean) => {
    setFormData((prev) => {
      const currentList = [...prev[name]];
      if (checked) {
        if (!currentList.includes(value)) currentList.push(value);
      } else {
        const index = currentList.indexOf(value);
        if (index > -1) currentList.splice(index, 1);
      }
      return { ...prev, [name]: currentList };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveStatus("idle");
    try {
      await onSave(formData);
      setSaveStatus("success");
      setTimeout(() => setSaveStatus("idle"), 2500);
    } catch (_) {
      setSaveStatus("error");
    } finally {
      setIsSaving(false);
    }
  };

  const activitiesList = ["Hiking", "Cycling", "Running", "Photography", "Walking", "Gardening", "Tennis", "Golf"];
  const travelList = ["Walking", "Cycling", "Driving", "Public Transit", "Flying"];

  return (
    <div className="glass-panel p-6" id="preferences-modal-root">
      <h3 className="text-base font-bold font-display tracking-tight text-white mb-1 flex items-center gap-2">
        <User size={18} className="text-indigo-400" /> AI Memory & Habits Settings
      </h3>
      <p className="text-xs text-slate-400 mb-6">Personalize your assistant's reasoning thresholds and daily advice</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-5" id="preferences-form">
        
        {/* Core Profile */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Temp Unit</label>
            <select
              name="tempUnit"
              value={formData.tempUnit}
              onChange={handleChange}
              className="glass-input text-sm w-full"
              id="select-pref-unit"
            >
              <option value="C" className="bg-slate-900">Celsius (°C)</option>
              <option value="F" className="bg-slate-900">Fahrenheit (°F)</option>
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Preferred Home City</label>
            <input
              type="text"
              name="preferredCity"
              value={formData.preferredCity}
              onChange={handleChange}
              placeholder="e.g. San Francisco"
              className="glass-input text-sm w-full"
              id="input-pref-city"
            />
          </div>
        </div>

        {/* Schedule timings */}
        <div className="grid grid-cols-3 gap-3">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono flex items-center gap-1">
              <Clock size={10} /> Wakeup
            </label>
            <input
              type="text"
              name="wakeupTime"
              value={formData.wakeupTime}
              onChange={handleChange}
              placeholder="e.g. 07:00"
              className="glass-input text-xs w-full"
              id="input-pref-wakeup"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Work Hours</label>
            <input
              type="text"
              name="workSchedule"
              value={formData.workSchedule}
              onChange={handleChange}
              placeholder="e.g. 09:00 - 17:00"
              className="glass-input text-xs w-full"
              id="input-pref-work"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Commute (Mins)</label>
            <input
              type="text"
              name="commuteTime"
              value={formData.commuteTime}
              onChange={handleChange}
              placeholder="e.g. 30"
              className="glass-input text-xs w-full"
              id="input-pref-commute"
            />
          </div>
        </div>

        {/* Walks preference */}
        <div className="flex flex-col gap-1">
          <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Walk Time Preference</label>
          <select
            name="walkPreference"
            value={formData.walkPreference}
            onChange={handleChange}
            className="glass-input text-xs w-full"
            id="select-pref-walk"
          >
            <option value="morning" className="bg-slate-900">Early Morning Strolls</option>
            <option value="evening" className="bg-slate-900">Relaxing Evening Walks</option>
            <option value="flexible" className="bg-slate-900">Flexible / Any hour</option>
          </select>
        </div>

        {/* Favorite Outdoor Activities */}
        <div>
          <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono block mb-2 flex items-center gap-1">
            <Heart size={10} className="text-indigo-400" /> Favorite Outdoor Hobbies
          </label>
          <div className="grid grid-cols-4 gap-2" id="pref-activities-checkboxes">
            {activitiesList.map((act) => (
              <label 
                key={act} 
                className={`flex items-center justify-center p-1.5 rounded-lg border text-[11px] cursor-pointer transition-all ${
                  formData.favoriteActivities.includes(act) 
                    ? "bg-indigo-500/15 border-indigo-500 text-indigo-200 shadow-[0_0_8px_rgba(99,102,241,0.15)]" 
                    : "bg-white/5 border-white/5 text-slate-400 hover:bg-white/10"
                }`}
                id={`label-act-${act.toLowerCase()}`}
              >
                <input
                  type="checkbox"
                  checked={formData.favoriteActivities.includes(act)}
                  onChange={(e) => handleArrayChange('favoriteActivities', act, e.target.checked)}
                  className="hidden"
                />
                {act}
              </label>
            ))}
          </div>
        </div>

        {/* Transport Styles */}
        <div>
          <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono block mb-2">
            Usual Commute / Travel Methods
          </label>
          <div className="flex flex-wrap gap-2" id="pref-travel-checkboxes">
            {travelList.map((m) => (
              <label 
                key={m} 
                className={`flex items-center justify-center px-2.5 py-1 rounded-full border text-[11px] cursor-pointer transition-all ${
                  formData.travelMethods.includes(m) 
                    ? "bg-indigo-500/15 border-indigo-500 text-indigo-200 shadow-[0_0_8px_rgba(99,102,241,0.15)]" 
                    : "bg-white/5 border-white/5 text-slate-400 hover:bg-white/10"
                }`}
                id={`label-travel-${m.toLowerCase().replace(" ", "-")}`}
              >
                <input
                  type="checkbox"
                  checked={formData.travelMethods.includes(m)}
                  onChange={(e) => handleArrayChange('travelMethods', m, e.target.checked)}
                  className="hidden"
                />
                {m}
              </label>
            ))}
          </div>
        </div>

        {/* Weather dislikes */}
        <div className="bg-white/5 p-3.5 rounded-xl border border-white/5 flex flex-col gap-2.5" id="pref-dislikes-container">
          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono flex items-center gap-1">
            <ShieldAlert size={11} className="text-indigo-400" /> Dislikes & Constraints
          </span>
          <div className="flex items-center gap-6">
            <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer" id="label-pref-dislikehot">
              <input
                type="checkbox"
                name="dislikesHot"
                checked={formData.dislikesHot}
                onChange={handleChange}
                className="rounded border-white/20 bg-slate-900 text-indigo-500 accent-indigo-500"
              />
              Avoid hot days (&gt;30°C)
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer" id="label-pref-dislikerain">
              <input
                type="checkbox"
                name="dislikesRain"
                checked={formData.dislikesRain}
                onChange={handleChange}
                className="rounded border-white/20 bg-slate-900 text-indigo-500 accent-indigo-500"
              />
              Avoid rainfall / wet days
            </label>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center gap-3 justify-end mt-2">
          {saveStatus === "success" && (
            <span className="text-xs text-green-400 font-medium font-display animate-pulse">✓ Preferences synchronized</span>
          )}
          {saveStatus === "error" && (
            <span className="text-xs text-rose-400 font-medium font-display">✗ Sync failed. Try again</span>
          )}
          <button
            type="submit"
            disabled={isSaving}
            className="glass-btn text-xs bg-indigo-500 hover:bg-indigo-400 text-white font-bold px-5 py-2.5 transition-all shadow-[0_0_15px_rgba(99,102,241,0.3)]"
            id="btn-pref-save"
          >
            {isSaving ? <RefreshCw className="animate-spin" size={14} /> : <Save size={14} />}
            {isSaving ? "Saving..." : "Save AI Memory"}
          </button>
        </div>

      </form>
    </div>
  );
}
