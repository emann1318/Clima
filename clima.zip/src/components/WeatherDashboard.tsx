import React from "react";
import { 
  Wind, 
  Droplets, 
  Sun, 
  Gauge, 
  Eye, 
  Compass, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle 
} from "lucide-react";
import { WeatherData, WeatherPreferences } from "../types";
import WeatherIcon from "./WeatherIcon";

interface WeatherDashboardProps {
  weather: WeatherData;
  preferences: WeatherPreferences;
}

export default function WeatherDashboard({ weather, preferences }: WeatherDashboardProps) {
  const { current, hourly, daily, alerts } = weather;
  const unit = preferences.tempUnit === "F" ? "°F" : "°C";

  // Convert temp if needed
  const formatTemp = (celsius: number) => {
    if (preferences.tempUnit === "F") {
      return Math.round((celsius * 9) / 5 + 32);
    }
    return Math.round(celsius);
  };

  // Cardinal direction for wind
  const getWindDirection = (deg: number) => {
    const directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
    const index = Math.round(((deg % 360) / 45)) % 8;
    return directions[index];
  };

  // UV index category label
  const getUVLabel = (uv: number) => {
    if (uv <= 2) return "Low";
    if (uv <= 5) return "Moderate";
    if (uv <= 7) return "High";
    if (uv <= 10) return "Very High";
    return "Extreme";
  };

  return (
    <div className="flex flex-col gap-6" id="weather-dashboard-root">
      {/* Alert Banner */}
      {alerts && alerts.length > 0 && (
        <div className="flex flex-col gap-2" id="dashboard-alerts-container">
          {alerts.map((alert, idx) => (
            <div 
              key={idx} 
              className={`flex items-start gap-3 p-4 rounded-xl border ${
                alert.severity === "severe" 
                  ? "bg-rose-500/10 border-rose-500/30 text-rose-200" 
                  : "bg-amber-500/10 border-amber-500/30 text-amber-200"
              }`}
              id={`alert-banner-${idx}`}
            >
              <AlertTriangle className="shrink-0 mt-0.5" size={20} />
              <div>
                <h4 className="font-semibold text-sm font-display tracking-tight">{alert.title}</h4>
                <p className="text-xs opacity-90 mt-0.5">{alert.description}</p>
                <span className="text-[10px] opacity-70 mt-1 block font-mono">{alert.time}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Primary Hero Header Weather Card */}
      <div 
        className="glass-panel bg-gradient-to-br from-indigo-600/15 via-blue-600/5 to-transparent border border-white/10 p-6 md:p-8 flex flex-col md:flex-row justify-between items-center gap-6 relative overflow-hidden shadow-2xl"
        id="dashboard-weather-hero"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="text-center md:text-left z-10">
          <div className="flex items-center gap-2 justify-center md:justify-start">
            <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold font-mono">Current Weather</span>
            {weather.dataSource && (
              <span className="text-[10px] bg-indigo-500/20 border border-indigo-500/40 text-indigo-200 px-2.5 py-0.5 rounded-full font-mono tracking-wider font-semibold animate-pulse">
                {weather.dataSource}
              </span>
            )}
          </div>
          <h2 className="text-3xl md:text-4xl font-bold font-display tracking-tight text-white mt-1">{weather.city}</h2>
          <p className="text-slate-300 mt-1 text-sm md:text-base capitalize">{current.description}</p>
          <div className="flex items-center gap-4 mt-2 justify-center md:justify-start">
            <span className="text-xs bg-white/5 border border-white/5 px-2.5 py-1 rounded-full text-slate-200 flex items-center gap-1 font-mono">
              <TrendingUp size={12} className="text-indigo-400" /> H: {formatTemp(current.high)}{unit}
            </span>
            <span className="text-xs bg-white/5 border border-white/5 px-2.5 py-1 rounded-full text-slate-200 flex items-center gap-1 font-mono">
              <TrendingDown size={12} className="text-indigo-400" /> L: {formatTemp(current.low)}{unit}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-6 z-10">
          <WeatherIcon code={current.weatherCode} size={84} />
          <div className="text-center md:text-right">
            <span className="text-6xl md:text-7xl font-extrabold font-display tracking-tighter text-white select-none">
              {formatTemp(current.temp)}
              <span className="text-4xl font-normal text-indigo-400 align-super">{unit}</span>
            </span>
            <p className="text-xs text-slate-400 font-mono mt-1">Feels like: {formatTemp(current.feelsLike)}{unit}</p>
          </div>
        </div>
      </div>

      {/* Hourly Forecast */}
      <div className="glass-panel p-5" id="dashboard-hourly-forecast">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 font-display mb-4">Hourly Forecast</h3>
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-thin" id="hourly-scroll-container">
          {hourly.slice(0, 16).map((hour, idx) => (
            <div 
              key={idx} 
              className="flex flex-col items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 min-w-[76px] text-center gap-2 hover:bg-white/10 hover:border-white/10 transition-all duration-200"
              id={`hourly-card-${idx}`}
            >
              <span className="text-xs text-slate-400 font-mono">{hour.time}</span>
              <WeatherIcon code={hour.weatherCode} size={28} />
              <span className="text-sm font-bold font-display">{formatTemp(hour.temp)}°</span>
              {hour.rainChance > 0 ? (
                <span className="text-[10px] font-mono text-cyan-400 font-semibold">{hour.rainChance}%</span>
              ) : (
                <span className="text-[10px] font-mono text-slate-500">-</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Bento Grid Cells */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="dashboard-bento-grid">
        
        {/* UV Index */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-uv">
          <div className="flex items-center gap-2 text-slate-400">
            <Sun size={16} />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">UV Index</span>
          </div>
          <div>
            <span className="text-3xl font-extrabold font-mono text-white">{current.uvIndex}</span>
            <p className="text-xs font-medium text-amber-400 mt-1">{getUVLabel(current.uvIndex)}</p>
          </div>
          <p className="text-[10px] text-slate-400 line-clamp-2">Protect your eyes and skin from solar radiation.</p>
        </div>

        {/* Humidity */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-humidity">
          <div className="flex items-center gap-2 text-slate-400">
            <Droplets size={16} />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">Humidity</span>
          </div>
          <div>
            <span className="text-3xl font-extrabold font-mono text-white">{current.humidity}%</span>
            <p className="text-xs text-slate-300 mt-1">The dew point is comfort-optimal.</p>
          </div>
          <p className="text-[10px] text-slate-400">Moisture levels affect thermal sensations.</p>
        </div>

        {/* Wind */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-wind">
          <div className="flex items-center gap-2 text-slate-400">
            <Wind size={16} />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">Wind</span>
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-extrabold font-mono text-white">{Math.round(current.windSpeed)}</span>
              <span className="text-xs text-slate-400 font-mono">km/h</span>
            </div>
            <p className="text-xs text-cyan-400 flex items-center gap-1 mt-1 font-mono font-semibold">
              <Compass size={12} /> {getWindDirection(current.windDirection)} ({current.windDirection}°)
            </p>
          </div>
          <p className="text-[10px] text-slate-400">Current atmospheric air velocity.</p>
        </div>

        {/* Air Quality */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-aqi">
          <div className="flex items-center gap-2 text-slate-400">
            <TrendingUp size={16} className="text-indigo-400" />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">Air Quality</span>
          </div>
          <div>
            <span className="text-3xl font-extrabold font-mono text-white">{current.airQuality}</span>
            <p className={`text-xs mt-1 font-semibold ${
              current.airQuality <= 50 
                ? "text-green-400" 
                : current.airQuality <= 100 
                ? "text-amber-400" 
                : "text-rose-400"
            }`}>{current.airQualityLabel}</p>
          </div>
          <div className="w-full bg-white/10 h-1.5 rounded-full mt-1.5 overflow-hidden">
            <div 
              style={{ width: `${Math.min(100, (current.airQuality / 200) * 100)}%` }} 
              className={`h-full rounded-full transition-all duration-500 ${
                current.airQuality <= 50 
                  ? "bg-green-400 shadow-[0_0_8px_#4ade80]" 
                  : current.airQuality <= 100 
                  ? "bg-amber-400 shadow-[0_0_8px_#fbbf24]" 
                  : "bg-rose-400 shadow-[0_0_8px_#f87171]"
              }`}
            ></div>
          </div>
        </div>

        {/* Visibility */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-visibility">
          <div className="flex items-center gap-2 text-slate-400">
            <Eye size={16} />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">Visibility</span>
          </div>
          <div>
            <span className="text-3xl font-extrabold font-mono text-white">{current.visibility.toFixed(1)}</span>
            <span className="text-xs text-slate-400 ml-1 font-mono">km</span>
            <p className="text-xs text-slate-300 mt-1">Excellent horizon visibility.</p>
          </div>
          <p className="text-[10px] text-slate-400">Aqueous cloud fog transparency.</p>
        </div>

        {/* Pressure */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-pressure">
          <div className="flex items-center gap-2 text-slate-400">
            <Gauge size={16} />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">Pressure</span>
          </div>
          <div>
            <span className="text-2xl font-extrabold font-mono text-white">{Math.round(current.pressure)}</span>
            <span className="text-xs text-slate-400 ml-1 font-mono">hPa</span>
            <p className="text-xs text-slate-300 mt-1">Atmospheric weight</p>
          </div>
          <p className="text-[10px] text-slate-400">Standard standard barometric load.</p>
        </div>

        {/* Sunrise */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-sunrise">
          <div className="flex items-center gap-2 text-slate-400">
            <TrendingUp size={16} className="text-amber-300" />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">Sunrise</span>
          </div>
          <div>
            <span className="text-2xl font-extrabold font-mono text-white">{current.sunrise}</span>
            <p className="text-xs text-slate-400 mt-1">Early dawn break</p>
          </div>
          <p className="text-[10px] text-slate-400">Optimal photography golden hour.</p>
        </div>

        {/* Sunset */}
        <div className="glass-panel p-4 flex flex-col justify-between h-36" id="bento-sunset">
          <div className="flex items-center gap-2 text-slate-400">
            <TrendingDown size={16} className="text-indigo-400" />
            <span className="text-xs font-semibold uppercase tracking-wider font-display">Sunset</span>
          </div>
          <div>
            <span className="text-2xl font-extrabold font-mono text-white">{current.sunset}</span>
            <p className="text-xs text-slate-400 mt-1">Dusk night onset</p>
          </div>
          <p className="text-[10px] text-slate-400">Twilight golden hour window.</p>
        </div>

      </div>

      {/* 7-Day Forecast */}
      <div className="glass-panel p-5" id="dashboard-daily-forecast">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 font-display mb-4">7-Day Forecast</h3>
        <div className="flex flex-col gap-3" id="daily-list-container">
          {daily.map((day, idx) => (
            <div 
              key={idx} 
              className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 hover:border-white/10 transition-all duration-200"
              id={`daily-row-${idx}`}
            >
              <span className="text-xs font-medium w-28 font-display text-white">{idx === 0 ? "Today" : day.date}</span>
              <div className="flex items-center gap-2 w-32">
                <WeatherIcon code={day.weatherCode} size={24} />
                <span className="text-xs text-slate-300 line-clamp-1 capitalize">{day.description}</span>
              </div>
              <div className="flex items-center gap-4 text-xs font-mono font-semibold justify-end w-24">
                <span className="text-white">{formatTemp(day.tempMax)}°</span>
                <span className="text-slate-500">{formatTemp(day.tempMin)}°</span>
              </div>
              <div className="text-right w-12 font-mono">
                {day.rainChance > 10 ? (
                  <span className="text-[10px] text-cyan-400 font-bold">{day.rainChance}%</span>
                ) : (
                  <span className="text-[10px] text-slate-500">-</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
