import React, { useState, useEffect } from "react";
import { Sparkles, Volume2, VolumeX, RefreshCw, Moon, Sun, Coffee } from "lucide-react";
import { WeatherData } from "../types";

interface DailyBriefingProps {
  weather: WeatherData;
  triggerRefresh: number;
}

export default function DailyBriefing({ weather, triggerRefresh }: DailyBriefingProps) {
  const [briefing, setBriefing] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [synth, setSynth] = useState<SpeechSynthesis | null>(null);
  const [utterance, setUtterance] = useState<SpeechSynthesisUtterance | null>(null);

  // Initialize speech synthesis
  useEffect(() => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      setSynth(window.speechSynthesis);
    }
  }, []);

  // Fetch briefing when weather changes or manual refresh triggers
  useEffect(() => {
    async function fetchBriefing() {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/ai/briefing?lat=${weather.lat}&lon=${weather.lon}&city=${encodeURIComponent(weather.city)}`);
        const data = await res.json();
        setBriefing((data.briefing || "").replace(/\*\*/g, ""));
      } catch (err) {
        console.error("Failed to fetch daily briefing", err);
        setBriefing(`Welcome back! Today in ${weather.city}, you can look forward to temperature ranges between ${Math.round(weather.current.low)}°C and ${Math.round(weather.current.high)}°C with ${weather.current.description}. Have a wonderful day!`);
      } finally {
        setIsLoading(false);
      }
    }

    if (weather) {
      fetchBriefing();
    }
  }, [weather, triggerRefresh]);

  // Handle Speech Toggle
  const handleSpeakToggle = () => {
    if (!synth) return;

    if (isSpeaking) {
      synth.cancel();
      setIsSpeaking(false);
    } else {
      if (!briefing) return;
      const textToSpeak = briefing.replace(/[^\w\s.,?!'"]/gi, ''); // clean formatting
      const newUtterance = new SpeechSynthesisUtterance(textToSpeak);
      
      newUtterance.onend = () => {
        setIsSpeaking(false);
      };
      newUtterance.onerror = () => {
        setIsSpeaking(false);
      };

      setUtterance(newUtterance);
      setIsSpeaking(true);
      synth.speak(newUtterance);
    }
  };

  // Stop speaking if component unmounts
  useEffect(() => {
    return () => {
      if (synth) {
        synth.cancel();
      }
    };
  }, [synth]);

  return (
    <div className="glass-panel p-5 relative overflow-hidden" id="daily-briefing-root">
      {/* Decorative gradient sphere */}
      <div className="absolute -top-12 -left-12 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

      <div className="flex items-center justify-between gap-4 mb-4 z-10 relative">
        <div className="flex items-center gap-2">
          <Coffee className="text-amber-400" size={18} />
          <h3 className="text-sm font-bold font-display uppercase tracking-wider text-slate-200">Daily Clima Briefing</h3>
        </div>

        <button
          onClick={handleSpeakToggle}
          disabled={isLoading || !briefing}
          className={`p-2 rounded-full border transition-all ${
            isSpeaking 
              ? "bg-indigo-500 border-indigo-400 text-white shadow-[0_0_12px_rgba(99,102,241,0.5)] animate-pulse" 
              : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
          }`}
          title={isSpeaking ? "Mute briefing audio" : "Listen to briefing"}
          id="btn-briefing-speak"
        >
          {isSpeaking ? <VolumeX size={15} /> : <Volume2 size={15} />}
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-6 gap-2 text-slate-400" id="briefing-loading">
          <RefreshCw className="animate-spin text-indigo-400" size={24} />
          <span className="text-xs font-mono">Synthesizing personal briefing...</span>
        </div>
      ) : (
        <div className="z-10 relative" id="briefing-content-container">
          <p className="text-xs md:text-sm text-slate-100 leading-relaxed font-sans font-light bg-white/5 p-4 rounded-xl border border-white/5 shadow-inner">
            {briefing.replace(/\*\*/g, "")}
          </p>
          <div className="flex justify-between items-center mt-3 text-[10px] font-mono text-slate-400">
            <span>Powered by Gemini 3.5 Flash</span>
            <span className="flex items-center gap-1">
              <Sparkles size={10} className="text-indigo-400" /> Grounded in Open-Meteo
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
