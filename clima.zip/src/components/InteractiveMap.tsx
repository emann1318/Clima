import React, { useState, useEffect, useRef } from "react";
import { Play, Pause, RefreshCw, Eye, Wind, Cloud, Thermometer, Layers } from "lucide-react";
import { WeatherData } from "../types";

interface InteractiveMapProps {
  weather: WeatherData;
}

type OverlayType = "radar" | "wind" | "clouds" | "temperature";

export default function InteractiveMap({ weather }: InteractiveMapProps) {
  const [activeOverlay, setActiveOverlay] = useState<OverlayType>("radar");
  const [isPlaying, setIsPlaying] = useState(true);
  const [timeStep, setTimeStep] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number | null>(null);
  const windParticles = useRef<{ x: number; y: number; vx: number; vy: number; life: number }[]>([]);

  // Initialize wind particles
  useEffect(() => {
    const particles = [];
    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * 400,
        y: Math.random() * 250,
        vx: (Math.random() * 1.5 + 0.5) * (weather.current.windSpeed / 10),
        vy: (Math.random() * 0.4 - 0.2) * (weather.current.windSpeed / 10),
        life: Math.random() * 100
      });
    }
    windParticles.current = particles;
  }, [weather.current.windSpeed]);

  // Handle animation cycle
  useEffect(() => {
    if (!isPlaying) {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      return;
    }

    const interval = setInterval(() => {
      setTimeStep((prev) => (prev + 1) % 12);
    }, 800);

    return () => clearInterval(interval);
  }, [isPlaying]);

  // Drawing simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = canvas.width;
    let height = canvas.height;

    const render = () => {
      // Clear
      ctx.clearRect(0, 0, width, height);

      // 1. Draw Simulated Map Background (Coastlines and grid)
      ctx.fillStyle = "#0A0A0C";
      ctx.fillRect(0, 0, width, height);

      // Draw grid
      ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw Landmass outlines (stylized vector shapes)
      ctx.fillStyle = "#111116";
      ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
      ctx.lineWidth = 1.5;
      
      // Shape 1 (Left land)
      ctx.beginPath();
      ctx.arc(60, 100, 80, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Shape 2 (Right coast)
      ctx.beginPath();
      ctx.moveTo(width - 120, 0);
      ctx.lineTo(width - 40, 80);
      ctx.lineTo(width - 80, 150);
      ctx.lineTo(width, height - 30);
      ctx.lineTo(width, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Shape 3 (Island center-bottom)
      ctx.beginPath();
      ctx.ellipse(220, 160, 45, 25, Math.PI / 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Draw active city marker
      ctx.fillStyle = "#6366f1";
      ctx.beginPath();
      ctx.arc(180, 90, 6, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.strokeStyle = "rgba(99, 102, 241, 0.4)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(180, 90, 12 + Math.sin(Date.now() / 200) * 4, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = "white";
      ctx.font = "bold 11px system-ui";
      ctx.fillText(weather.city, 195, 94);

      // 2. Draw Simulated Overlays
      if (activeOverlay === "radar") {
        // RADAR - precipitation storms (Green, Yellow, Red cells moving with timeStep)
        const rainChance = weather.current.rainChance;
        if (rainChance > 10) {
          ctx.save();
          // Set opacity
          ctx.globalAlpha = 0.65;
          const shift = timeStep * 15;

          // Storm cell 1
          const radialGrad1 = ctx.createRadialGradient(
            120 + shift, 80 + shift / 2, 10,
            120 + shift, 80 + shift / 2, 70
          );
          radialGrad1.addColorStop(0, "rgba(239, 68, 68, 0.9)"); // Heavy Red
          radialGrad1.addColorStop(0.3, "rgba(245, 158, 11, 0.8)"); // Medium Yellow
          radialGrad1.addColorStop(0.6, "rgba(34, 197, 94, 0.7)"); // Light Green
          radialGrad1.addColorStop(1, "rgba(34, 197, 94, 0)");
          
          ctx.fillStyle = radialGrad1;
          ctx.beginPath();
          ctx.arc(120 + shift, 80 + shift / 2, 70, 0, Math.PI * 2);
          ctx.fill();

          // Storm cell 2 (smaller, trailing)
          if (rainChance > 50) {
            const radialGrad2 = ctx.createRadialGradient(
              80 + shift, 130 + shift / 2, 5,
              80 + shift, 130 + shift / 2, 40
            );
            radialGrad2.addColorStop(0, "rgba(245, 158, 11, 0.85)");
            radialGrad2.addColorStop(0.5, "rgba(34, 197, 94, 0.7)");
            radialGrad2.addColorStop(1, "rgba(34, 197, 94, 0)");
            ctx.fillStyle = radialGrad2;
            ctx.beginPath();
            ctx.arc(80 + shift, 130 + shift / 2, 40, 0, Math.PI * 2);
            ctx.fill();
          }

          ctx.restore();
        } else {
          // Clear radar banner
          ctx.fillStyle = "rgba(255,255,255,0.4)";
          ctx.font = "11px monospace";
          ctx.fillText("No precipitation cells active", 110, height - 20);
        }

      } else if (activeOverlay === "wind") {
        // WIND - moving particles/streamlines
        ctx.save();
        ctx.strokeStyle = "rgba(103, 232, 249, 0.5)";
        ctx.lineWidth = 1.5;
        
        const speedMultiplier = weather.current.windSpeed / 12;

        windParticles.current.forEach((p) => {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 3, p.y - p.vy * 3);
          ctx.stroke();

          // Update position
          p.x += p.vx * (isPlaying ? 1 : 0);
          p.y += p.vy * (isPlaying ? 1 : 0);
          p.life -= isPlaying ? 0.8 : 0;

          // Recycle
          if (p.x > width || p.x < 0 || p.y > height || p.y < 0 || p.life <= 0) {
            p.x = Math.random() * width;
            p.y = Math.random() * height;
            p.life = Math.random() * 100 + 50;
          }
        });
        ctx.restore();

      } else if (activeOverlay === "clouds") {
        // CLOUDS - fluffy moving cloud shapes
        ctx.save();
        ctx.globalAlpha = 0.45;
        ctx.fillStyle = "rgba(241, 245, 249, 0.8)";
        
        const shiftX = timeStep * 12;
        const cloudCount = 3;

        for (let c = 0; c < cloudCount; c++) {
          const cx = (100 + c * 130 + shiftX) % (width + 100) - 50;
          const cy = 60 + c * 40;

          ctx.beginPath();
          ctx.arc(cx, cy, 25, 0, Math.PI * 2);
          ctx.arc(cx + 15, cy - 10, 30, 0, Math.PI * 2);
          ctx.arc(cx + 35, cy, 25, 0, Math.PI * 2);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();

      } else if (activeOverlay === "temperature") {
        // TEMPERATURE OVERLAY - warm gradient representation
        ctx.save();
        ctx.globalAlpha = 0.5;

        // Draw temperature heatmap (warm on land, cool on sea)
        const curTemp = weather.current.temp;
        let baseColor = "rgba(59, 130, 246, 0.6)"; // Blue/cool
        if (curTemp > 30) {
          baseColor = "rgba(239, 68, 68, 0.6)"; // Red/hot
        } else if (curTemp > 20) {
          baseColor = "rgba(245, 158, 11, 0.5)"; // Orange/warm
        } else if (curTemp > 10) {
          baseColor = "rgba(16, 185, 129, 0.4)"; // Green/mild
        }

        const gradient = ctx.createRadialGradient(180, 90, 20, 180, 90, 180);
        gradient.addColorStop(0, baseColor);
        gradient.addColorStop(0.5, "rgba(16, 185, 129, 0.2)");
        gradient.addColorStop(1, "rgba(59, 130, 246, 0.1)");

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
      }

      if (isPlaying) {
        requestRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [activeOverlay, weather, isPlaying, timeStep]);

  return (
    <div className="glass-panel p-5 flex flex-col gap-4" id="interactive-map-root">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold font-display tracking-tight text-white flex items-center gap-2">
            <Layers size={18} className="text-indigo-400" /> Dynamic Interactive Radar Map
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Simulated atmospheric forecasting system</p>
        </div>

        {/* Overlay Selector */}
        <div className="flex items-center gap-1 bg-white/5 p-1 rounded-lg border border-white/10" id="map-overlay-selector">
          <button
            onClick={() => setActiveOverlay("radar")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              activeOverlay === "radar" ? "bg-indigo-500 text-white font-bold shadow-lg" : "text-slate-300 hover:bg-white/5"
            }`}
            id="btn-overlay-radar"
          >
            <Eye size={12} className="inline mr-1" /> Radar
          </button>
          <button
            onClick={() => setActiveOverlay("wind")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              activeOverlay === "wind" ? "bg-indigo-500 text-white font-bold shadow-lg" : "text-slate-300 hover:bg-white/5"
            }`}
            id="btn-overlay-wind"
          >
            <Wind size={12} className="inline mr-1" /> Wind
          </button>
          <button
            onClick={() => setActiveOverlay("clouds")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              activeOverlay === "clouds" ? "bg-indigo-500 text-white font-bold shadow-lg" : "text-slate-300 hover:bg-white/5"
            }`}
            id="btn-overlay-clouds"
          >
            <Cloud size={12} className="inline mr-1" /> Clouds
          </button>
          <button
            onClick={() => setActiveOverlay("temperature")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              activeOverlay === "temperature" ? "bg-indigo-500 text-white font-bold shadow-lg" : "text-slate-300 hover:bg-white/5"
            }`}
            id="btn-overlay-temp"
          >
            <Thermometer size={12} className="inline mr-1" /> Temp
          </button>
        </div>
      </div>

      {/* Canvas Viewport */}
      <div className="relative rounded-xl overflow-hidden border border-white/10 shadow-inner bg-[#0A0A0C]">
        <canvas 
          ref={canvasRef} 
          width={560} 
          height={260} 
          className="w-full h-[260px] block"
          id="map-canvas-viewport"
        />

        {/* Legend Overlay */}
        <div className="absolute bottom-3 left-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-white/10 text-[10px] font-mono flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-400"></span>
            <span>{weather.city}</span>
          </div>
          {activeOverlay === "radar" && (
            <div className="flex items-center gap-1">
              <span className="w-12 h-2 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 rounded"></span>
              <span>Lght - Hvy Rain</span>
            </div>
          )}
          {activeOverlay === "wind" && (
            <span className="text-indigo-300 font-bold">Velocity: {weather.current.windSpeed} km/h</span>
          )}
          {activeOverlay === "clouds" && (
            <span>Opacity: Cloud density</span>
          )}
          {activeOverlay === "temperature" && (
            <span className="text-amber-400">Heat contour gradients</span>
          )}
        </div>
      </div>

      {/* Map Timeline Controls */}
      <div className="flex items-center justify-between bg-white/5 px-4 py-2 rounded-xl border border-white/10" id="map-timeline-controls">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-8 h-8 rounded-full bg-indigo-500 text-white flex items-center justify-center hover:bg-indigo-400 active:scale-95 transition-all shadow-[0_0_12px_rgba(99,102,241,0.3)]"
            id="btn-toggle-play"
          >
            {isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" />}
          </button>
          <div>
            <span className="text-xs font-semibold block text-white font-display">Forecast Loop</span>
            <span className="text-[10px] text-slate-400 font-mono">Step: {timeStep + 1} / 12 (+{(timeStep * 10)} mins)</span>
          </div>
        </div>

        {/* Playback Progress Indicator */}
        <div className="flex gap-1 w-1/2" id="timeline-progress-bar">
          {Array.from({ length: 12 }).map((_, stepIdx) => (
            <div 
              key={stepIdx} 
              className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                stepIdx === timeStep ? "bg-indigo-400 scale-y-125 shadow-[0_0_8px_rgba(99,102,241,0.5)]" : "bg-white/10"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
