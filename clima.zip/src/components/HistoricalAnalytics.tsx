import React, { useState, useEffect } from "react";
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { TrendingUp, RefreshCw, BarChart2, Calendar } from "lucide-react";
import { HistoricalRecord, WeatherPreferences } from "../types";

interface HistoricalAnalyticsProps {
  city: string;
  preferences: WeatherPreferences;
  refreshTrigger: number;
}

export default function HistoricalAnalytics({ city, preferences, refreshTrigger }: HistoricalAnalyticsProps) {
  const [historyData, setHistoryData] = useState<HistoricalRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [chartType, setChartType] = useState<"temp" | "rain" | "aqi">("temp");

  useEffect(() => {
    async function fetchHistory() {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/history?city=${encodeURIComponent(city)}`);
        const data = await res.json();
        
        // Reverse data to show in chronological order (left to right)
        if (Array.isArray(data)) {
          const sorted = [...data].reverse().map((record: any) => ({
            ...record,
            formattedDate: new Date(record.timestamp).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
            displayTemp: preferences.tempUnit === "F" ? Math.round((record.temp * 9) / 5 + 32) : Math.round(record.temp)
          }));
          setHistoryData(sorted);
        }
      } catch (err) {
        console.error("Failed to fetch historical record logs:", err);
      } finally {
        setIsLoading(false);
      }
    }

    if (city) {
      fetchHistory();
    }
  }, [city, preferences.tempUnit, refreshTrigger]);

  const unit = preferences.tempUnit === "F" ? "°F" : "°C";

  return (
    <div className="glass-panel p-5 flex flex-col gap-4" id="historical-analytics-root">
      
      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold font-display tracking-tight text-white flex items-center gap-2">
            <BarChart2 size={18} className="text-indigo-400" /> Historical Weather Analytics
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Atmospheric records and climate trends for {city}</p>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-white/5 p-1 rounded-lg border border-white/10 text-xs shrink-0" id="analytics-tabs-container">
          <button
            onClick={() => setChartType("temp")}
            className={`px-3 py-1 rounded-md font-medium transition-all ${
              chartType === "temp" ? "bg-indigo-500 text-white font-bold shadow-lg" : "text-slate-300 hover:bg-white/5"
            }`}
            id="tab-chart-temp"
          >
            Temperature
          </button>
          <button
            onClick={() => setChartType("rain")}
            className={`px-3 py-1 rounded-md font-medium transition-all ${
              chartType === "rain" ? "bg-indigo-500 text-white font-bold shadow-lg" : "text-slate-300 hover:bg-white/5"
            }`}
            id="tab-chart-rain"
          >
            Precipitation
          </button>
          <button
            onClick={() => setChartType("aqi")}
            className={`px-3 py-1 rounded-md font-medium transition-all ${
              chartType === "aqi" ? "bg-indigo-500 text-white font-bold shadow-lg" : "text-slate-300 hover:bg-white/5"
            }`}
            id="tab-chart-aqi"
          >
            Air Quality
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="h-64 flex flex-col items-center justify-center gap-2 text-slate-400" id="analytics-loading">
          <RefreshCw className="animate-spin text-indigo-400" size={24} />
          <span className="text-xs font-mono">Loading history charts...</span>
        </div>
      ) : historyData.length < 2 ? (
        <div className="h-64 flex flex-col items-center justify-center text-center p-6 bg-white/5 border border-white/5 rounded-xl text-slate-400" id="analytics-empty">
          <Calendar size={32} className="text-slate-500 mb-2" />
          <span className="text-sm font-semibold text-slate-300">Awaiting Historical Logs</span>
          <p className="text-xs text-slate-500 mt-1 max-w-xs">
            As you search and update weather queries for {city}, historical climate logs will accumulate automatically to form analytical curves.
          </p>
        </div>
      ) : (
        <div className="h-64 w-full" id="analytics-chart-container">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === "temp" ? (
              <AreaChart data={historyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="formattedDate" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} unit={unit} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0a0a0c", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px" }}
                  labelStyle={{ color: "#94a3b8", fontWeight: "bold", fontSize: "11px" }}
                  itemStyle={{ color: "#fff", fontSize: "12px" }}
                />
                <Area type="monotone" dataKey="displayTemp" name="Avg Temp" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorTemp)" />
              </AreaChart>
            ) : chartType === "rain" ? (
              <BarChart data={historyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="formattedDate" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} unit="%" tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0a0a0c", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px" }}
                  labelStyle={{ color: "#94a3b8", fontWeight: "bold", fontSize: "11px" }}
                  itemStyle={{ color: "#fff", fontSize: "12px" }}
                />
                <Bar dataKey="rainChance" name="Precipitation Risk" fill="#6366f1" radius={[4, 4, 0, 0]} maxBarSize={30} />
              </BarChart>
            ) : (
              <AreaChart data={historyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorAqi" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="formattedDate" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0a0a0c", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px" }}
                  labelStyle={{ color: "#94a3b8", fontWeight: "bold", fontSize: "11px" }}
                  itemStyle={{ color: "#fff", fontSize: "12px" }}
                />
                <Area type="monotone" dataKey="aqi" name="US EPA AQI" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorAqi)" />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
