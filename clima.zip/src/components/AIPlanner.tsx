import React, { useState } from "react";
import { Sparkles, Compass, CheckCircle2, Package, RefreshCw, Star, Info } from "lucide-react";
import { WeatherData, WeatherPreferences, ActivityPlan } from "../types";

interface AIPlannerProps {
  weather: WeatherData;
  preferences: WeatherPreferences;
}

export default function AIPlanner({ weather, preferences }: AIPlannerProps) {
  const [activity, setActivity] = useState("");
  const [plan, setPlan] = useState<ActivityPlan | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activity.trim()) return;

    setIsLoading(true);
    try {
      const res = await fetch("/api/ai/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          activity: activity.trim(),
          weatherData: weather,
          preferences
        })
      });
      const data = await res.json();
      if (data.plan) {
        setPlan(data.plan);
      }
    } catch (err) {
      console.error("AI Planning error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const getRatingColor = (rating: string) => {
    switch (rating.toLowerCase()) {
      case "excellent":
        return "bg-emerald-500/10 border-emerald-500/30 text-emerald-300";
      case "good":
        return "bg-indigo-500/10 border-indigo-500/30 text-indigo-300";
      case "fair":
        return "bg-amber-500/10 border-amber-500/30 text-amber-300";
      default:
        return "bg-rose-500/10 border-rose-500/30 text-rose-300";
    }
  };

  const planPresets = ["Hiking", "Golden Hour Photography", "Outdoor Cycling", "Flight Travel", "Beach Picnic", "Gardening"];

  return (
    <div className="glass-panel p-5 flex flex-col gap-5" id="ai-planner-root">
      <div>
        <h3 className="text-base font-bold font-display tracking-tight text-white flex items-center gap-2">
          <Compass size={18} className="text-indigo-400" /> Smart Outdoor & Travel AI Planner
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">Determine the perfect window and packing gear list for any activity</p>
      </div>

      {/* Input query form */}
      <form onSubmit={handleGeneratePlan} className="flex gap-2" id="planner-form">
        <input
          type="text"
          value={activity}
          onChange={(e) => setActivity(e.target.value)}
          placeholder="e.g. Hike Yosemite, Wash car, Fly to New York"
          className="glass-input text-xs flex-grow"
          required
          id="input-planner-activity"
        />
        <button
          type="submit"
          disabled={isLoading || !activity.trim()}
          className="glass-btn bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-xs px-4 shadow-[0_0_12px_rgba(99,102,241,0.2)]"
          id="btn-planner-submit"
        >
          {isLoading ? <RefreshCw className="animate-spin" size={14} /> : <Sparkles size={14} />}
          Plan
        </button>
      </form>

      {/* Preset Suggestions */}
      {!plan && !isLoading && (
        <div className="flex flex-col gap-2" id="planner-presets-container">
          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 font-mono">Quick ideas:</span>
          <div className="flex flex-wrap gap-1.5">
            {planPresets.map((preset) => (
              <button
                key={preset}
                onClick={() => setActivity(preset)}
                className="px-2.5 py-1 rounded-full bg-white/5 border border-white/5 hover:bg-white/10 hover:border-white/15 text-[10px] text-slate-300 transition-all font-sans"
                id={`btn-preset-${preset.toLowerCase().replace(/ /g, "-")}`}
              >
                {preset}
              </button>
            ))}
          </div>
        </div>
      )}

      {isLoading && (
        <div className="flex flex-col items-center justify-center py-10 gap-3" id="planner-loading">
          <RefreshCw className="animate-spin text-indigo-400" size={28} />
          <div className="text-center">
            <span className="text-sm font-semibold text-white block font-display">Analyzing conditions suitability...</span>
            <span className="text-xs text-slate-400 font-mono mt-1">Cross-referencing weather curves with activities...</span>
          </div>
        </div>
      )}

      {/* Planning Report Results */}
      {plan && !isLoading && (
        <div className="flex flex-col gap-4 animate-fade-in" id="planner-report-results">
          
          {/* Headline Recommendation */}
          <div className="bg-indigo-500/5 border border-indigo-500/15 p-4 rounded-xl flex flex-col gap-2 shadow-inner">
            <div className="flex items-center justify-between gap-4">
              <span className="text-xs bg-indigo-500/20 text-indigo-200 font-bold font-mono px-2.5 py-0.5 rounded-full">
                Best Window: {plan.bestDay}
              </span>
              <span className="flex items-center gap-1 text-amber-400 text-xs font-semibold">
                <Star size={12} fill="currentColor" /> Premium Suitability
              </span>
            </div>
            <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-sans mt-1">
              {plan.recommendation}
            </p>
          </div>

          {/* Forecast Slots Timeline */}
          <div className="flex flex-col gap-2" id="planner-timeline-container">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono">Window Suitability Grid:</span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {plan.timeline.map((slot, idx) => (
                <div 
                  key={idx} 
                  className={`p-3 rounded-xl border flex flex-col justify-between gap-2 transition-all ${getRatingColor(slot.rating)}`}
                  id={`planner-slot-${idx}`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold font-display">{slot.time}</span>
                    <span className="text-[10px] uppercase font-bold font-mono px-1.5 py-0.5 bg-white/10 rounded">
                      {slot.rating}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs font-mono block font-semibold text-white">{slot.weather}</span>
                    <p className="text-[10px] text-slate-300 mt-1 leading-snug">{slot.tips}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Packing suggestions */}
          <div className="bg-slate-900/40 p-4 rounded-xl border border-white/5 flex flex-col gap-2" id="planner-packing-container">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 font-mono flex items-center gap-1">
              <Package size={11} className="text-indigo-400" /> Smart Packing & Gear Guidelines:
            </span>
            <ul className="grid grid-cols-2 gap-2 mt-1" id="planner-packing-list">
              {plan.packingSuggestions.map((item, idx) => (
                <li key={idx} className="text-xs text-slate-300 flex items-center gap-1.5" id={`packing-item-${idx}`}>
                  <CheckCircle2 size={12} className="text-indigo-400 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>
      )}
    </div>
  );
}
